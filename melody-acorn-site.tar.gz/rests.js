/* Explicit silence lives inside a lyric's time, alongside its sounding notes. */
let restEditFocus=null;
function restsEnabled(p=project()){return p.level===0||p.level>=22;}
function restTeaching(p=project()){return p.level===22&&advancedStep(p)?.kind==='rests';}
function restParts(li,i,p=project()){
 const l=p.lines[li];if(!l||!Number.isInteger(i)||i<0||i>=lyricUnits(l.text).length)return [];return l.melody?.[i]||[{d:l.durations[i]??1,p:l.pitches[i],staccato:!!l.staccato?.[i]}];
}
function hasWrittenRest(p=project()){return p.lines.some(l=>Object.values(l.melody||{}).some(parts=>parts.some(n=>n.rest===true)));}
function restOptions(li,i,si=0,p=project()){
 const parts=restParts(li,i,p),n=parts[si];if(!n||n.rest||n.p===null||parts.length>=8&&!parts[si+1]?.rest)return [];
 return [.25,.5,1,1.5,2].filter(d=>n.d-d>=.25);
}
function syncLyricPitch(l,i){const first=l.melody?.[i]?.find(n=>!n.rest);if(first)l.pitches[i]=first.p;}
function insertRestAfter(li,i,si,d,p=project()){
 if(!restsEnabled(p)||!restOptions(li,i,si,p).includes(d))return false;
 const l=p.lines[li],parts=clone(restParts(li,i,p));parts[si].d-=d;
 if(parts[si+1]?.rest)parts[si+1].d+=d;else parts.splice(si+1,0,{d,p:null,rest:true});
 l.melody??={};l.melody[i]=parts;syncLyricPitch(l,i);return true;
}
function canTurnIntoRest(li,i,si,p=project()){
 const parts=restParts(li,i,p);return restsEnabled(p)&&!!parts[si]&&!parts[si].rest&&parts[si].p!==null&&parts.some((n,j)=>j!==si&&!n.rest&&n.p!==null);
}
function turnIntoRest(li,i,si,p=project()){
 if(!canTurnIntoRest(li,i,si,p))return false;const l=p.lines[li],parts=clone(restParts(li,i,p));parts[si]={d:parts[si].d,p:null,rest:true};l.melody??={};l.melody[i]=parts;syncLyricPitch(l,i);return true;
}
function removeWrittenRest(li,i,si,p=project()){
 const l=p.lines[li],parts=clone(restParts(li,i,p));if(!parts[si]?.rest)return false;
 let target=si-1;while(target>=0&&parts[target].rest)target--;
 if(target<0){target=si+1;while(target<parts.length&&parts[target].rest)target++;}
 if(!parts[target])return false;parts[target].d+=parts[si].d;parts.splice(si,1);l.melody[i]=parts;syncLyricPitch(l,i);return true;
}
function restOptionSVG(duration,gap){
 const sounded=duration,pieces=spellRhythm(0,sounded,8),restX=35+pieces.length*45,width=restX+30;
 return `<svg viewBox="0 0 ${width} 78" width="150" height="78" aria-label="唱${beatLabel(sounded)}，停${beatLabel(gap)}"><g color="#365b45">${pieces.map((n,i)=>{const x=30+i*45;return head(n.d,x,48)+stem({...n,x},48,true,15)+dot(n.d,x,48)+(i<pieces.length-1?`<path d="M${x+7} 59Q${x+23} 72 ${x+38} 59" fill="none" stroke="currentColor"/>`:'');}).join('')}${glyph(gap>=2?'restHalf':gap>=1?'restQuarter':gap>=.5?'rest8':'rest16',restX,37)}${dot(gap,restX+5,37)}</g></svg>`;
}
function restPreviewEvents(parts){let t=0;return parts.map((n,i)=>{const event={...n,t,followedByRest:parts[i+1]?.rest===true};t+=n.d;return event;});}
function openLyricRestMenu(li,i){
 const si=restParts(li,i).findLastIndex(n=>!n.rest);if(si>=0)openRestMenu(li,i,si);
}
function closeRestEdit(focus=null){
 if(focus)restEditFocus={...focus,project:project()};
 stop();$('#modal').close();selected=null;refreshScore();syncRestGate();
 if(focus&&restTeaching())locateRestLesson();
}
function openRestMenu(li,i,si=0){
 const p=project(),l=p.lines[li],part=restParts(li,i,p)[si],m=$('#modal');if(!restsEnabled(p)||!part)return;
 if(part.rest){
  m.innerHTML=`<h2>「${esc(lyricUnits(l.text)[i])}」里的休止</h2><p>这里停 ${beatLabel(part.d)}。恢复后，这段时间会接回旁边的音。</p><button id="restoreRest" class="primary">恢复发声</button><div class="actions"><button id="closeRestMenu">返回乐谱</button></div>`;
  $('#restoreRest').onclick=()=>{mutate(()=>removeWrittenRest(li,i,si));closeRestEdit();};
 }else{
  const choices=restOptions(li,i,si,p),canReplace=canTurnIntoRest(li,i,si,p);
  m.innerHTML=`<h2>在「${esc(lyricUnits(l.text)[i])}」后加入休止符</h2><p>休止符就是无声的空白音符。</p><p class="hint">把这个字最后的音缩短，留出的时间不发声。这个字的总时长不变。</p><button id="previewOriginalRest">▶ 原来的唱法</button><div class="choices rest-choices">${choices.map((d,j)=>`<div class="choice">${restOptionSVG(part.d,d)}<div>唱${beatLabel(part.d-d)} + 停${beatLabel(d)}</div><div class="option-actions"><button data-rest-preview="${j}">▶ 留空后</button><button data-rest-use="${j}" class="primary">加入休止符</button></div></div>`).join('')}</div>${!choices.length?'<p class="hint">最后这个音已经很短了。先点击乐谱下方的歌词，把这个字的时长加长，再来加入休止符。</p>':''}${canReplace?'<button id="turnIntoRest">把最后这个音改为休止符</button>':''}<div class="actions"><button id="closeRestMenu">返回乐谱</button></div>`;
  $('#previewOriginalRest').onclick=()=>playEvents(restPreviewEvents(restParts(li,i,p)));
  $$('[data-rest-preview]').forEach(b=>b.onclick=()=>{const gap=choices[+b.dataset.restPreview],parts=clone(restParts(li,i,p));parts[si].d-=gap;if(parts[si+1]?.rest)parts[si+1].d+=gap;else parts.splice(si+1,0,{d:gap,p:null,rest:true});playEvents(restPreviewEvents(parts));});
  $$('[data-rest-use]').forEach(b=>b.onclick=()=>{mutate(()=>insertRestAfter(li,i,si,choices[+b.dataset.restUse]));closeRestEdit({li,i,si:si+1});});
  if(canReplace)$('#turnIntoRest').onclick=()=>{mutate(()=>turnIntoRest(li,i,si));closeRestEdit({li,i,si});};
 }
 $('#closeRestMenu').onclick=()=>{stop();m.close();};if(!m.open)m.showModal();
}
function restLessonTarget(p=project()){
 let li=p.lines.findIndex(l=>l.text.includes('争渡'));if(li<0)li=Math.min(1,p.lines.length-1);
 const l=p.lines[li],i=l.text.includes('争渡')?l.text.indexOf('争渡')+1:lyricUnits(l.text).length-1;
 const parts=restParts(li,i,p),si=Math.max(0,parts.findLastIndex(n=>!n.rest)),preferred={li,i,si};
 if(restOptions(li,i,si,p).length||canTurnIntoRest(li,i,si,p))return preferred;
 for(let line=0;line<p.lines.length;line++)for(let char=0;char<lyricUnits(p.lines[line].text).length;char++){
  const at=restParts(line,char,p).findLastIndex(n=>!n.rest);
  if(at>=0&&(restOptions(line,char,at,p).length||canTurnIntoRest(line,char,at,p)))return {li:line,i:char,si:at};
 }
 return preferred;
}
function restLessonFocus(p=project()){
 if(restEditFocus?.project===p&&restParts(restEditFocus.li,restEditFocus.i,p)[restEditFocus.si]?.rest){const {li,i,si}=restEditFocus;return {li,i,si};}
 for(let li=0;li<p.lines.length;li++)for(let i=0;i<lyricUnits(p.lines[li].text).length;i++){
  const si=restParts(li,i,p).findIndex(n=>n.rest);if(si>=0)return {li,i,si};
 }
 return null;
}
function restLessonGuideHTML(){
 const p=project(),focus=restLessonFocus(p),target=focus||restLessonTarget(p),word=esc(lyricUnits(p.lines[target.li].text)[target.i]);
 const ready=restOptions(target.li,target.i,target.si,p).length||canTurnIntoRest(target.li,target.i,target.si,p);
 return `<div><strong>${focus?`第 ${focus.li+1} 句「${word}」：这里停${beatLabel(restParts(focus.li,focus.i,p)[focus.si].d)}`:ready?'右键点击上方“歌词节奏”里的音符，可以在这个字后加入休止符。':`先点击歌词「${word}」，把时长选长一点，再右键点击上方“歌词节奏”里的音符。`}</strong><p>${focus?'休止符就是无声的空白音符，播放到框出的地方会停一下。点击休止符可以恢复发声。':'休止符就是无声的空白音符，播放到这里会停一下。'}</p></div><div class="rest-guide-actions"><button id="locateRest">${focus?'查看这处休止':`找到第 ${target.li+1} 句的「${word}」`}</button>${focus?'<button id="playRestPhrase">▶ 播放这一句</button>':''}</div>`;
}
function locateRestLesson(){
 const focus=restLessonFocus(),selector=focus?`.user-rest[data-li="${focus.li}"][data-i="${focus.i}"][data-si="${focus.si}"]`:'.rest-teaching-target';
 const el=$(selector);el?.scrollIntoView?.({block:'center',behavior:'smooth'});
}
function syncRestGate(){
 if(!restTeaching())return;
 if($('#next'))$('#next').disabled=!hasWrittenRest()||project().lines.some((_,li)=>!!sentenceError(li));
 const guide=$('#restLessonGuide');if(!guide)return;guide.innerHTML=restLessonGuideHTML();
 if($('#locateRest'))$('#locateRest').onclick=locateRestLesson;
 if($('#playRestPhrase'))$('#playRestPhrase').onclick=()=>{const focus=restLessonFocus();if(focus)playAll(false,focus.li);};
}
function renderRestLesson(){
 const p=project();$('#stage').innerHTML=heading('加入休止','让旋律停一下，再接着唱～','')+`<div id="restLessonGuide" class="rest-lesson-guide" role="status" aria-live="polite">${restLessonGuideHTML()}</div>`+editingControls()+`<div id="scoreArea">${advancedScoreHTML()}</div>`;bindPlayback();
 nav(true,'',()=>{if(!hasWrittenRest()){toast('试着在一个音后留一点空隙');return;}for(let li=0;li<p.lines.length;li++){const issue=sentenceError(li);if(issue){toast(`第 ${li+1} 句：${issue}`);return;}}mutate(()=>p.complete=true);advanceAdvanced();});syncRestGate();
}
function installRests(){
 const oldBind=bindScore,oldSVG=engravingSVG,oldCadence=isCadenceNote,oldRefresh=refreshScore;
 isCadenceNote=function(p,n){if(n.rest)return false;const parts=p.lines[n.li]?.melody?.[n.i];if(!parts?.some(v=>v.rest))return oldCadence(p,n);return !!cadenceRequirement(p,n.li)&&n.i===p.lines[n.li].pitches.length-1&&n.last&&(n.si??0)===parts.findLastIndex(v=>!v.rest);};
 engravingSVG=function(row,mode='combined',editable=true){let svg=oldSVG(row,mode,editable);if(editable&&mode==='combined'&&restTeaching()){
  const p=project(),focus=restLessonFocus(p),notes=row.measures.flatMap(m=>m.notes);let extra='';
  if(focus){
   const rests=notes.filter(n=>n.rest&&n.i>=0),matches=n=>n.li===focus.li&&n.i===focus.i&&(n.si??0)===focus.si;
   for(const n of rests)extra+=`<g class="rest-teaching-rest" data-rest-li="${n.li}" data-rest-i="${n.i}" data-rest-si="${n.si??0}" pointer-events="none"><rect x="${n.x-22}" y="146" width="44" height="59" rx="9" fill="#f6d486" fill-opacity=".12" stroke="#b77d20" stroke-width="${matches(n)?2.5:1.5}"/></g>`;
   const n=rests.find(matches);if(n){const x=Math.max(100,Math.min(row.width-100,n.x)),d=restParts(focus.li,focus.i,p)[focus.si].d;extra+=`<g class="rest-teaching-label" pointer-events="none"><text x="${x}" y="105" text-anchor="middle" font-size="13" fill="#8b641e">这里停${beatLabel(d)}</text><path d="M${x} 112L${n.x} 143" fill="none" stroke="#c69b53" stroke-width="1.2"/></g>`;}
  }else{
   const target=restLessonTarget(p),n=notes.find(n=>n.li===target.li&&n.i===target.i&&!n.rest&&n.first&&n.syllableFirst!==false);
   if(n){const x=Math.max(195,Math.min(row.width-195,n.x)),ready=restOptions(target.li,target.i,target.si,p).length||canTurnIntoRest(target.li,target.i,target.si,p);extra+=`<g class="rest-teaching-target" pointer-events="none"><rect x="${n.x-23}" y="5" width="46" height="74" rx="9" fill="none" stroke="#c58c2c" stroke-width="2"/><path d="M${n.x} 81L${x} 91" fill="none" stroke="#c69b53"/><text x="${x}" y="105" text-anchor="middle" font-size="13" fill="#8b641e">${ready?'右键这里，在这个字后加入休止符':'先点击下方歌词，把这个字选长一点'}</text></g>`;}
  }
  svg=svg.replace('</g></svg>',extra+'</g></svg>');
 }return svg;};
 bindScore=function(){oldBind();if(!restsEnabled())return;$$('.lyric-rhythm[role="button"]').forEach(el=>{
  const open=e=>{e.preventDefault();e.stopPropagation();openLyricRestMenu(+el.dataset.rhythmLi,+el.dataset.rhythmI);},key=el.onkeydown;
  el.oncontextmenu=open;el.onkeydown=e=>{if(e.key==='ContextMenu'||e.shiftKey&&e.key==='F10')open(e);else key?.(e);};
  el.setAttribute?.('aria-description','左键拆分旋律节奏；右键在这个字后加入休止符');
 });$$('.user-rest').forEach(el=>{const open=e=>{e.preventDefault();e.stopPropagation();openRestMenu(+el.dataset.li,+el.dataset.i,+(el.dataset.si||0));};el.onclick=open;el.oncontextmenu=open;el.onkeydown=e=>{if(e.key==='Enter'||e.key===' ')open(e);};});syncRestGate();};
 refreshScore=function(){oldRefresh();syncRestGate();};
}
