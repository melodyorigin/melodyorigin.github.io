/* In-app quick reference. Opening it never changes a composition or its step. */
(function(){
 const sections=[
  {title:'常用操作',heads:['想做什么','怎么操作'],note:'闯关中的功能会随关卡逐步开放。',rows:[
   ['试听节拍和速度','第 16 关起，或自由创作初始信息中，选好节拍、速度后点“试听”；再次点击停止。'],
   ['划分词组','点击字与字之间的分隔线；也可拖动已有分隔线。'],
   ['重新划分词组','点该句的“调整第 X 句歌词划分”，修改后保存。'],
   ['安排歌词节奏','拖动深色圆点调整相邻字的长短，拖动句尾双竖线调整最后一个字。'],
   ['输入、调整音高','点击歌词对应的五线谱位置；选中音符后，上下拖动或按 ↑ / ↓。'],
   ['一个字唱多个音','点击谱子上方的歌词节奏音符，选择拆分，再调整各个音的音高。'],
   ['添加、移除跳音','先选中五线谱音符，再点一次打开选项；也可直接右键，选择“添加跳音”或“移除跳音”。'],
   ['英文音节','第24关：按发音安排音符，例如 Morn-ing。编辑歌词时用 - 修正音节，空格分开单词。'],
   ['升号、降号','第25关起或自由创作：选中五线谱音符后再点一次，或直接右键，在跳音旁边选择 ♯、♭。'],
   ['触屏操作','双击上方音符打开选项；长按代替右键。拖动音符调整音高，双指捏合缩放。'],
   ['还原记号','第27关：同一小节保留第一个升 G，点击第二个 G 选择 ♮，让它回到本位音。无需还原时会提示。'],
   ['加入休止','第 22 关起或自由创作中，右键上方“歌词节奏”里的音符，选择“加入休止符”。休止符就是无声的空白音符；新增空拍，原音时长不变，后面的歌词顺延。'],
   ['恢复休止处的声音','点击或右键新增空拍，调整时长或删除；删除后后续歌词前移。'],
   ['只听一句','点“▶ 第 X 句”或“播放整句”。'],
   ['播放整首','点“整首播放”或按空格；再次按空格暂停，点 ■ 停止。']
  ]},
  {title:'快捷键',heads:['按键','作用'],note:'先选中音符再改音高。输入文字或打开对话框时，不会触发谱面快捷键；可选音受当前调式和关卡限制。',rows:[
   ['空格','播放 / 暂停'],
   ['↑ / ↓','当前音符升高 / 降低一级'],
   ['← / →','选中前一个 / 后一个音符'],
   ['C D E F G A B','输入 C4—B4 对应位置的音，升降按当前调式'],
   ['Shift + C D E F G A B','输入 C5—B5 对应位置的音，升降按当前调式'],
   ['Shift + ↑ / ↓','当前音符升高 / 降低一个八度'],
   ['Ctrl / ⌘ + Z','撤销（也可点顶部 ↶）'],
   ['Ctrl / ⌘ + Shift + Z\nCtrl / ⌘ + Y','重做（也可点顶部 ↷）'],
   ['Enter','已聚焦歌词组或节奏音符时，打开选项'],
   ['Esc','关闭对话框']
  ]},
  {title:'复制与分段',heads:['想做什么','怎么操作'],note:'复制保留目标句的歌词；框出的空缺，需要你补上节奏或音高。',rows:[
   ['给歌词分段','换行划分乐句，逗号、句号不另起乐句；空一行划分段落。'],
   ['编辑歌词、段落','自由创作建新歌时填写；第 15 关可调整分段，第 16 关起可改词和分段，第 22 关使用固定歌词与分段。'],
   ['复制一句','在目标句的“复制第 X 句旋律”中填来源句号，点“复制”。'],
   ['复制一段','在目标段第一句的“复制第 X 段旋律”中填来源段号，点“复制”。'],
   ['整句升高、降低','点该句工具区的 ↑ / ↓ 箭头，整句一起移动。'],
   ['补齐复制后的差异','点击框出的歌词或音符，可改节奏、改音高，也可拆分音符。'],
   ['调整小节线','第23关教学：拖动框出的小节线，依次选“否 → 否 → 是”。后续关卡和自由创作也可直接拖动小节线，不强制使用。'],
   ['检查乐谱','点击“下一步”前的“检查乐谱”，查看遗漏；红框只标出需要补齐或调整的位置。']
  ]},
  {title:'保存与排版',heads:['用途','去哪里操作'],note:'第一关暂不开放导出。游客作品保存在当前设备；登录并同步成功后，可换设备继续。建议定期备份。',rows:[
   ['调整每行小节数','点“乐谱换行”，选“按乐句自动划分”或指定每行小节数。'],
   ['只在某个小节折行','右键这一小节后的小节线，选“强制折行”，让当前行在这里结束。'],
   ['从下一行移来一小节','右键行末的小节线，选“强制取消折行”。每次移上来一个小节，可以连续操作。'],
   ['恢复统一换行','点“乐谱换行”→“恢复自动排版”，或重新选择每行小节数；也可以用“后退”撤销换行操作。'],
   ['填写作品题目和姓名','在“完成作品”填写标题、作词者、作曲者。'],
   ['五线谱 / 简谱 PDF','“保存作品”→ 对应 PDF，用于打印、分享乐谱。'],
   ['MP3 音频','“保存作品”→ MP3，用于直接收听、分享。'],
   ['MIDI 文件','“保存作品”→ MIDI，用于继续编曲。'],
   ['MusicXML 乐谱','“保存作品”→ MusicXML，用其他制谱软件编辑。'],
   ['备份当前作品的进度','编辑页顶部“备份工程”，保存 JSON 文件。每首作品分别备份。'],
   ['查看外部乐谱','顶部“打开乐谱或工程”可查看 MusicXML 五线谱和 MIDI 各音轨的钢琴卷帘谱。'],
   ['恢复备份','顶部“打开乐谱或工程”，选择 JSON 备份；确认后替换对应作品的进度。']
  ]},
  {title:'关卡与作品',heads:['想做什么','去哪里操作'],note:'点上方“关闭”，或按 Esc，就能回到刚才的页面。',rows:[
   ['开始、继续闯关','首页 → 闯关模式 → 开始闯关 / 继续闯关。'],
   ['查看当前关歌词','点上方“第 X 关 · 作品名”；点“继续创作”返回原步骤。'],
   ['查看上一关、下一关','点“上一关：作品名”或“下一关：作品名”，先进入对应封面。'],
   ['按段创作（第 21 关起）','编辑歌词与分段后进入“旋律创作”。每段先划分歌词节奏，再在整段乐谱上配节奏、拆音和调整音高；完成后进入下一段。'],
   ['返回已做过的步骤','点“上一步”，或上方已解锁的步骤名称。'],
   ['新建自己的歌曲','自由创作 → 新的歌曲，填写作品名并粘贴歌词。'],
   ['继续旧作品','自由创作 → 旧的印迹，选择要继续的歌曲。'],
   ['删除、恢复作品','旧的印迹 → 作品旁的“删除”；误删可在下方“已删除作品”中恢复。'],
   ['设置节拍、速度、调式','自由创作的“设置作品初始信息”中选择，也可自定节拍和 BPM。']
  ]}
 ];
 const button=document.querySelector('#openGuide');if(!button)return;
 button.onclick=()=>{
  const modal=document.querySelector('#modal');
  modal.classList.add('operation-guide');modal.setAttribute('aria-labelledby','operationGuideTitle');
  modal.innerHTML=`<div class="operation-guide-head"><h2 id="operationGuideTitle">操作指南</h2><button id="closeOperationGuide" type="button" autofocus>关闭 ×</button></div><div class="operation-guide-tabs" role="tablist" aria-label="指南分类">${sections.map((s,i)=>`<button type="button" id="guideTab${i}" role="tab" data-guide-tab="${i}" aria-controls="guidePanel" aria-selected="${i===0}" tabindex="${i===0?0:-1}">${s.title}</button>`).join('')}</div><div id="guidePanel" class="operation-guide-panel" role="tabpanel"></div>`;
  const tabs=[...modal.querySelectorAll('[data-guide-tab]')],panel=modal.querySelector('#guidePanel');
  function select(index){
   const section=sections[index];
   tabs.forEach((tab,i)=>{tab.setAttribute('aria-selected',String(i===index));tab.tabIndex=i===index?0:-1;});
   panel.setAttribute('aria-labelledby',`guideTab${index}`);
   panel.innerHTML=`<table class="operation-guide-table"><thead><tr>${section.heads.map(h=>`<th scope="col">${h}</th>`).join('')}</tr></thead><tbody>${section.rows.map(([action,how])=>`<tr><th scope="row">${esc(action).replace(/\n/g,'<br>')}</th><td>${esc(how)}</td></tr>`).join('')}</tbody></table><p class="operation-guide-note">${esc(section.note)}</p>`;
   panel.scrollTop=0;
  }
  tabs.forEach((tab,i)=>{
   tab.onclick=()=>select(i);
   tab.onkeydown=e=>{let next;if(e.key==='ArrowRight')next=(i+1)%tabs.length;else if(e.key==='ArrowLeft')next=(i+tabs.length-1)%tabs.length;else if(e.key==='Home')next=0;else if(e.key==='End')next=tabs.length-1;else return;e.preventDefault();select(next);tabs[next].focus();};
  });
  modal.querySelector('#closeOperationGuide').onclick=()=>modal.close();
  modal.addEventListener('close',()=>{modal.classList.remove('operation-guide');modal.removeAttribute('aria-labelledby');},{once:true});
  select(0);modal.showModal();
 };
})();
