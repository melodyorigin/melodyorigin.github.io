/* In-app quick reference. Opening it never changes a composition or its step. */
(function(){
 const sections=[
  {title:'常用操作',heads:['想做什么','怎么操作'],note:'闯关中的功能会随关卡逐步开放。',rows:[
   ['试听节拍和速度','第 16 关起，或自由创作初始信息中，选好节拍、速度后点“试听”；再次点击停止。'],
   ['划分词组','点击字与字之间的分隔线；也可拖动已有分隔线。'],
   ['重新划分词组','点该句的“调整第 X 句歌词划分”，修改后保存。'],
   ['安排歌词节奏','拖动深色圆点调整相邻字的长短，拖动句尾双竖线调整最后一个字。'],
   ['节奏偏好','在“选择速度”下方，或页头“联系我”旁选择工整或自由。'],
   ['输入、调整音高','点击歌词对应的五线谱位置；选中音符后，上下拖动或按 ↑ / ↓。'],
   ['一个字唱多个音','点击谱子上方的歌词节奏音符，选择拆分，再调整各个音的音高。'],
   ['添加、移除跳音','先选中五线谱音符，再点一次打开选项；也可直接右键，选择“添加跳音”或“移除跳音”。'],
   ['英文音节','第24关：按发音安排音符，例如 Morn-ing。编辑歌词时用 - 修正音节，空格分开单词。'],
   ['升号、降号','第25关起或自由创作：选中五线谱音符后再点一次，或直接右键，在跳音旁边选择 ♯、♭。'],
   ['触屏操作','双击上方音符打开选项；长按代替右键。拖动音符调整音高，双指捏合缩放。'],
   ['还原记号','第27关：同一小节保留第一个升 G，点击第二个 G 选择 ♮，让它回到本位音。无需还原时会提示。'],
   ['加入休止','第 22 关起或自由创作中，右键上方“歌词节奏”里的音符，选择“加入休止符”。休止符就是无声的空白音符；新增空拍，原音时长不变，后面的歌词顺延。'],
   ['恢复休止处的声音','点击或右键新增空拍，调整时长或删除；删除后后续歌词前移。'],
   ['只听一句','点“▶ 第 X 句”或“播放整句”。'],
   ['播放整首','点“整首播放”或按空格；再次按空格暂停，点 ■ 停止。']
  ]},
  {title:'快捷键',heads:['按键','作用'],note:'先选中音符再改音高。输入文字或打开对话框时，不会触发谱面快捷键；可选音受当前调式和关卡限制。',rows:[
   ['空格','播放 / 暂停'],
   ['↑ / ↓','当前音符升高 / 降低一级'],
   ['← / →','选中前一个 / 后一个音符'],
   ['C D E F G A B','输入 C4—B4 对应位置的音，升降按当前调式'],
   ['Shift + C D E F G A B','输入 C5—B5 对应位置的音，升降按当前调式'],
   ['Shift + ↑ / ↓','当前音符升高 / 降低一个八度'],
   ['Ctrl / ⌘ + Z','撤销（也可点顶部 ↶）'],
   ['Ctrl / ⌘ + Shift + Z\nCtrl / ⌘ + Y','重做（也可点顶部 ↷）'],
   ['Enter','已聚焦歌词组或节奏音符时，打开选项'],
   ['Esc','关闭对话框']
  ]},
  {title:'复制与分段',heads:['想做什么','怎么操作'],note:'复制保留目标句的歌词；框出的空缺，需要你补上节奏或音高。',rows:[
   ['给歌词分段','换行划分乐句，逗号、句号不另起乐句；空一行划分段落。'],
   ['编辑歌词、段落','自由创作建新歌时填写；第 15 关可调整分段，第 16 关起可改词和分段，第 22 关使用固定歌词与分段。'],
   ['复制一句','在目标句的“复制第 X 句旋律”中填来源句号，点“复制”。'],
   ['复制一段','在目标段第一句的“复制第 X 段旋律”中填来源段号，点“复制”。'],
   ['整句升高、降低','点该句工具区的 ↑ / ↓ 箭头，整句一起移动。'],
   ['补齐复制后的差异','点击框出的歌词或音符，可改节奏、改音高，也可拆分音符。'],
   ['调整小节线','第23关教学：拖动框出的小节线，依次选“否 → 否 → 是”。后续关卡和自由创作也可直接拖动小节线，不强制使用。'],
   ['检查乐谱','点击“下一步”前的“检查乐谱”，查看遗漏；红框只标出需要补齐或调整的位置。']
  ]},
  {title:'保存与排版',heads:['用途','去哪里操作'],note:'第一关暂不开放导出。作品保存在当前浏览器；换设备时，可先备份工程，再在另一台设备打开。',rows:[
   ['调整每行小节数','点“乐谱换行”，选“按乐句自动划分”或指定每行小节数。'],
   ['只在某个小节折行','右键这一小节后的小节线，选“强制折行”，让当前行在这里结束。'],
   ['从下一行移来一小节','右键行末的小节线，选“强制取消折行”。每次移上来一个小节，可以连续操作。'],
   ['恢复统一换行','点“乐谱换行”→“恢复自动排版”，或重新选择每行小节数；也可以用“后退”撤销换行操作。'],
   ['填写作品题目和姓名','在“完成作品”填写标题、作词者、作曲者。'],
   ['五线谱 / 简谱 PDF','“保存作品”→ 对应 PDF，用于打印、分享乐谱。'],
   ['MP3 音频','“保存作品”→ MP3，用于直接收听、分享。'],
   ['MIDI 文件','“保存作品”→ MIDI，用于继续编曲。'],
   ['MusicXML 乐谱','“保存作品”→ MusicXML，用其他制谱软件编辑。'],
   ['备份当前作品的进度','编辑页顶部“备份工程”，保存 JSON 文件。每首作品分别备份。'],
   ['查看外部乐谱','顶部“打开乐谱或工程”可查看 MusicXML 五线谱和 MIDI 各音轨的钢琴卷帘谱。'],
   ['恢复备份','顶部“打开乐谱或工程”，选择 JSON 备份；确认后替换对应作品的进度。']
  ]},
  {title:'关卡与作品',heads:['想做什么','去哪里操作'],note:'点上方“关闭”，或按 Esc，就能回到刚才的页面。',rows:[
   ['开始、继续闯关','首页 → 闯关模式 → 开始闯关 / 继续闯关。'],
   ['查看当前关歌词','点上方“第 X 关 · 作品名”；点“继续创作”返回原步骤。'],
   ['查看上一关、下一关','点“上一关：作品名”或“下一关：作品名”，先进入对应封面。'],
   ['按段创作（第 21 关起）','编辑歌词与分段后进入“旋律创作”。每段先划分歌词节奏，再在整段乐谱上配节奏、拆音和调整音高；完成后进入下一段。'],
   ['返回已做过的步骤','点“上一步”，或上方已解锁的步骤名称。'],
   ['新建自己的歌曲','自由创作 → 新的歌曲，填写作品名并粘贴歌词。'],
   ['继续旧作品','自由创作 → 旧的印迹，选择要继续的歌曲。'],
   ['删除、恢复作品','旧的印迹 → 作品旁的“删除”；误删可在下方“已删除作品”中恢复。'],
   ['设置节拍、速度、调式','自由创作的“设置作品初始信息”中选择，也可自定节拍和 BPM。']
  ]}
 ];
 const demos = {
  rhythm: { title: '调整节奏', keywords:'安排节奏 拖动节奏 节奏条 节奏点', file: 'rhythm-drag', help: '左右拖深色圆点可移动字的起点，点一下也能用按钮微调。第一个点调整首字时长，句尾双线调整尾音时长。' },
  groups: { title: '划分词组', keywords:'划分节奏 划分歌词 歌词分组', file: 'grouping', help: '点两个字之间的竖线，将词组分开。再点同一条线可以合并。' },
  pitch: { title: '调整音高', keywords:'安排音高 拖动音高 拖动音符 升高 降低', file: 'pitch-drag', help: '在五线谱上按住音符，往上拖会升高，往下拖会降低。' }
 };
 function prepareDemo(video,path){
  video.muted=true;video.defaultMuted=true;video.playsInline=true;
  video.hidden=false;
  video.parentElement.querySelector('.demo-animation')?.remove();
  video.parentElement.querySelector('.demo-alternative')?.remove();
  const alternative=document.createElement('button');
  alternative.type='button';alternative.className='demo-alternative';alternative.textContent='查看动画演示';
  function animate(){
   if(!video.isConnected||video.hidden)return;
   video.pause();video.hidden=true;alternative.hidden=true;
   const image=document.createElement('img');image.className='demo-animation guide-demo-player';image.alt=video.getAttribute('aria-label');image.src=path+'.gif';video.after(image);
  }
  alternative.onclick=animate;video.after(alternative);
  video.onerror=animate;video.poster=path+'.jpg';video.src=path+'.mp4';
  return ()=>video.play().catch(error=>{if(error.name!=='AbortError')animate();});
 }
 // A split lesson plays the clip at its control; the header guide remains browsable.
 document.addEventListener('click',event=>{
  const summary=event.target.closest?.('.sentence-operation-demo > summary');
  if(!summary)return;
  event.preventDefault();
  const detail=summary.parentElement,info=demos[detail.dataset.sentenceDemo];
  let video=detail.querySelector('video');
  if(detail.open){video?.pause();detail.open=false;return;}
  detail.open=true;
  if(!video){
   video=document.createElement('video');
   video.className='guide-demo-player';video.controls=true;video.playsInline=true;
   video.preload='none';video.setAttribute('aria-label',summary.textContent);
   const path='assets/tutorials/'+info.file;
   const fallback=document.createElement('p');
   fallback.className='hint';fallback.hidden=true;fallback.textContent=info.help;
   video.addEventListener('error',()=>{fallback.hidden=false;});
   detail.append(video,fallback);video.startDemo=prepareDemo(video,path);
  }
  video.startDemo();
 });
 const button=document.querySelector('#openGuide');if(!button)return;
 function openGuide(opener, initialDemo='rhythm', playImmediately=false, match=null) {
  const modal=document.querySelector('#modal');
  if(modal.open)return;
  modal.classList.add('operation-guide');modal.setAttribute('aria-labelledby','operationGuideTitle');
  modal.innerHTML=`<div class="operation-guide-head"><h2 id="operationGuideTitle">操作指南</h2><button id="closeOperationGuide" type="button" autofocus>关闭 ×</button></div><div class="operation-guide-tabs" role="tablist" aria-label="指南分类">${sections.map((s,i)=>`<button type="button" id="guideTab${i}" role="tab" data-guide-tab="${i}" aria-controls="guidePanel" aria-selected="${i===0}" tabindex="${i===0?0:-1}">${i===0?'视频演示':s.title}</button>`).join('')}</div><div id="guidePanel" class="operation-guide-panel" role="tabpanel"></div>`;
  const tabs=[...modal.querySelectorAll('[data-guide-tab]')],panel=modal.querySelector('#guidePanel');
  let demo=initialDemo;
  function stopDemo(){panel.querySelector('video')?.pause();}
  function showDemo(play){
   const info=demos[demo];
   const video=panel.querySelector('video');
   video.pause();
   const path='assets/tutorials/'+info.file;
   video.setAttribute('aria-label',info.title+'操作演示');
   const start=prepareDemo(video,path);
   for(const b of panel.querySelectorAll('[data-guide-clip]'))b.setAttribute('aria-pressed',String(b.dataset.guideClip===demo));
   const hint=panel.querySelector('.demo-transcript');
   hint.querySelector('p').textContent=info.help;
   if(play)start();
  }
  function select(index,play=false){
   stopDemo();
   const section=sections[index];
   tabs.forEach((tab,i)=>{tab.setAttribute('aria-selected',String(i===index));tab.tabIndex=i===index?0:-1;});
   panel.setAttribute('aria-labelledby',`guideTab${index}`);
   const text=`<table class="operation-guide-table"><thead><tr>${section.heads.map(h=>`<th scope="col">${h}</th>`).join('')}</tr></thead><tbody>${section.rows.map(([action,how])=>`<tr><th scope="row">${esc(action).replace(/\n/g,'<br>')}</th><td>${esc(how)}</td></tr>`).join('')}</tbody></table><p class="operation-guide-note">${esc(section.note)}</p>`;
   if(index===0){
    panel.innerHTML=`<div class="guide-demo-picker" role="group" aria-label="选择演示">${Object.entries(demos).map(([key,info])=>`<button type="button" data-guide-clip="${key}">${info.title}</button>`).join('')}</div><video class="guide-demo-player" controls playsinline preload="none" aria-describedby="guide-demo-description"></video><details class="demo-transcript"><summary>查看动作说明</summary><p id="guide-demo-description"></p></details><details class="guide-common-text"><summary>其他常用操作</summary>${text}</details>`;
    panel.querySelectorAll('[data-guide-clip]').forEach(b=>b.onclick=()=>{demo=b.dataset.guideClip;showDemo(true);});
    showDemo(play);
   }else panel.innerHTML=text;
   panel.scrollTop=0;
  }
  tabs.forEach((tab,i)=>{
   tab.onclick=()=>select(i);
   tab.onkeydown=e=>{let next;if(e.key==='ArrowRight')next=(i+1)%tabs.length;else if(e.key==='ArrowLeft')next=(i+tabs.length-1)%tabs.length;else if(e.key==='Home')next=0;else if(e.key==='End')next=tabs.length-1;else return;e.preventDefault();select(next);tabs[next].focus();};
  });
  modal.querySelector('#closeOperationGuide').onclick=()=>{stopDemo();modal.close();};
  modal.addEventListener('close',()=>{
   stopDemo();
   modal.classList.remove('operation-guide');modal.removeAttribute('aria-labelledby');
   if(opener?.isConnected)opener.focus({preventScroll:true});
  },{once:true});
  modal.showModal();select(match?.section??0,playImmediately);
  if(match){
   const common=panel.querySelector('.guide-common-text');if(common)common.open=true;
   const row=panel.querySelectorAll('tbody tr')[match.row];
   if(row){row.classList.add('matched-feature');row.scrollIntoView({block:'nearest'});}
  }
 }
 button.onclick=()=>{
  const phase=document.querySelector('.sentence-substeps [data-sentence-phase].active');
  openGuide(button,['groups','rhythm','pitch'][Number(phase?.dataset.sentencePhase)]||'rhythm');
 };
 document.addEventListener('click',event=>{
  const trigger=event.target.closest?.('button[data-operation-demo]');
  if(trigger && Object.hasOwn(demos,trigger.dataset.operationDemo))openGuide(trigger,trigger.dataset.operationDemo,true);
 });
 const search=document.querySelector('#featureSearch'),results=document.querySelector('#featureMatches');
 const topics=sections.flatMap((section,si)=>section.rows.map(([title,help],row)=>({title,help,section:si,row})));
 for(const [clip,info] of Object.entries(demos))topics.unshift({title:info.title+'演示',help:info.help,keywords:info.keywords,clip});
 let shown=[],active=-1;
 const normalize=text=>text.normalize('NFKC').toLowerCase().replace(/\s/g,'');
 const segmenter=typeof Intl.Segmenter==='function'?new Intl.Segmenter('zh',{granularity:'word'}):null;
 function hideMatches(){
  results.hidden=true;active=-1;search.setAttribute('aria-expanded','false');search.removeAttribute('aria-activedescendant');
 }
 function choose(index){
  const topic=shown[index];if(!topic)return;
  hideMatches();
  if(topic.clip){
   const detail=document.querySelector(`#stage [data-sentence-demo="${topic.clip}"]`);
   if(detail){if(!detail.open)detail.firstElementChild.click();detail.scrollIntoView({block:'center'});detail.firstElementChild.focus({preventScroll:true});}
   else openGuide(search,topic.clip,true);
  }else openGuide(search,'rhythm',false,topic);
 }
 function findFeatures(){
  const query=normalize(search.value.trim());
  if(!query){hideMatches();return;}
  const words=segmenter?[...segmenter.segment(search.value)].filter(s=>s.isWordLike).map(s=>normalize(s.segment)):[];
  const rank=t=>{
   const title=normalize(t.title),help=normalize(t.help),keywords=(t.keywords||'').split(' ').map(normalize);
   if(title.includes(query)||keywords.includes(query))return 3;
   if(help.includes(query))return 2;
   const body=title+' '+help+' '+keywords.join(' ');
   return words.length>1&&words.every(word=>body.includes(word))?1:0;
  };
  shown=topics.map(topic=>({topic,rank:rank(topic)})).filter(item=>item.rank).sort((a,b)=>b.rank-a.rank).slice(0,8).map(item=>item.topic);
  results.replaceChildren();active=-1;search.removeAttribute('aria-activedescendant');
  for(const [index,topic] of shown.entries()){
   const option=document.createElement('div');option.id='featureMatch'+index;option.setAttribute('role','option');option.setAttribute('aria-selected','false');
   option.textContent=topic.title;option.onclick=()=>choose(index);results.append(option);
  }
  if(!shown.length)results.textContent='没有找到相关功能';
  results.hidden=false;search.setAttribute('aria-expanded','true');
 }
 search.addEventListener('input',findFeatures);search.addEventListener('focus',findFeatures);
 search.addEventListener('keydown',event=>{
  if(event.isComposing||event.keyCode===229)return;
  if(event.key==='Escape'){hideMatches();return;}
  if(results.hidden||!shown.length)return;
  if(event.key==='Enter'){event.preventDefault();choose(Math.max(active,0));return;}
  if(!['ArrowUp','ArrowDown'].includes(event.key))return;
  event.preventDefault();active=event.key==='ArrowDown'?(active+1)%shown.length:(active<=0?shown.length-1:active-1);
  [...results.children].forEach((o,i)=>o.setAttribute('aria-selected',String(i===active)));
  const option=results.children[active];search.setAttribute('aria-activedescendant',option.id);option.scrollIntoView({block:'nearest'});
 });
 document.addEventListener('pointerdown',e=>{if(!e.target.closest('.feature-search'))hideMatches();});
 search.parentElement.addEventListener('focusout',e=>{if(e.relatedTarget&&!search.parentElement.contains(e.relatedTarget))hideMatches();});
})();
