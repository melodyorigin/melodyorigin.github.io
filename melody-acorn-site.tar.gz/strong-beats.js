/* Lesson 19: locate metrical accents without changing the player's melody. */
function strongBeatPattern(p=project()){
 const [numerator,denominator]=meterParts(p),beats=[{metric:0,strength:'primary',label:'强拍'}];
 if(numerator===4&&denominator===4)beats.push({metric:2,strength:'secondary',label:'次强'});
 if(numerator===6&&denominator===8)beats.push({metric:1.5,strength:'secondary',label:'次强'});
 return beats;
}
function strongBeatPositions(row,p=project()){
 const bar=barBeats(p),epsilon=.00001,positions=[];
 const metric=n=>Number.isFinite(n.metric)?n.metric:Number.isFinite(n.local)?n.local:((n.t%bar)+bar)%bar;
 for(const measure of row.measures){
  const notes=measure.notes,first=notes[0];if(!first)continue;
  // Pickups begin partway through a metrical bar. A filtered phrase can also
  // begin after beat one, so a beat is shown only when a visible event spans it.
  const offset=Number.isFinite(first.local)?metric(first)-first.local:measure.pickup?bar-measure.duration:0;
  const duration=Number.isFinite(measure.duration)?measure.duration:bar;
  for(const beat of strongBeatPattern(p)){
   if(beat.metric<offset-epsilon||beat.metric>=offset+duration-epsilon)continue;
   const note=notes.find(n=>beat.metric>=metric(n)-epsilon&&beat.metric<metric(n)+n.d-epsilon);
   if(!note)continue;
   const elapsed=Math.max(0,beat.metric-metric(note)),fraction=elapsed/note.d;
   // Engraving spacing is not proportional across different notes. Interpolate
   // only inside the occupying event's slot; never snap to the next attack.
   const x=Math.max(measure.x+14,Math.min(measure.x+measure.width-17,note.x+fraction*note.slot));
   positions.push({...beat,measure:measure.number,local:beat.metric-offset,x,y:note.rest?174:noteY(note.p??28),li:note.li,i:note.i,si:note.si??0,
    kind:note.rest?'rest':elapsed>epsilon||note.first===false?'sustain':'attack'});
  }
 }
 return positions;
}
function strongBeatOverlay(row,p=project()){
 const marks=strongBeatPositions(row,p);if(!marks.length)return '';
 let svg='<g class="strong-beat-guide" pointer-events="none" aria-label="强拍位置提示">';
 for(const mark of marks){
  const primary=mark.strength==='primary',stroke=primary?'#ab843b':'#aab39b',ink=primary?'#87672c':'#879277';
  const top=mark.y-15,labelY=top-6,kind=mark.kind==='sustain'?'，延音经过':mark.kind==='rest'?'，休止':'';
  svg+=`<g class="strong-beat-position ${mark.strength}" data-measure="${mark.measure}" data-metric="${mark.metric}" data-local="${mark.local}" data-kind="${mark.kind}" data-li="${mark.li}" data-i="${mark.i}" data-si="${mark.si}" aria-label="第 ${mark.measure+1} 小节${mark.label}${kind}"><rect class="strong-beat-frame" x="${mark.x-15}" y="${top}" width="30" height="30" rx="6" fill="none" stroke="${stroke}" stroke-width="${primary?1.6:1.2}"${mark.kind==='sustain'?' stroke-dasharray="3 3"':''}/><rect x="${mark.x-13}" y="${labelY-9}" width="26" height="12" rx="3" fill="#fffefa" fill-opacity=".94"/><text x="${mark.x}" y="${labelY}" text-anchor="middle" font-size="10" fill="${ink}">${mark.label}</text></g>`;
 }
 if(row.strongBeatsFirst??row.first)svg+='<text class="strong-beat-hint" x="15" y="347" font-size="12" fill="#7b886e">框出的是强拍位置，B（变宫）尽量少放在这里。</text>';
 return svg+'</g>';
}
function installStrongBeats(){
 const oldModel=systemModel,oldSVG=engravingSVG;
 systemModel=function(p=project(),focusLi=null){
  const rows=oldModel(p,focusLi);rows.forEach((row,i)=>{row.strongBeatsFirst=i===0;});return rows;
 };
 engravingSVG=function(row,mode='combined',editable=true){
  const svg=oldSVG(row,mode,editable),p=project();
  if(p.level!==19||!editable||mode!=='combined')return svg;
  return svg.replace('</g></svg>',strongBeatOverlay(row,p)+'</g></svg>');
 };
}
