/* Chapters 24–25: syllable underlay and per-note accidental/articulation menu. */
function eventMidi(e,p=project()){
 return e.alter===undefined?studioMidi(e.p,p):12*(Math.floor(e.p/7)+1)+SEMI[((e.p%7)+7)%7]+e.alter;
}
function noteAlter(line,i,si=0){return line.melody?.[i]?.[si]?.alter??line.accidentals?.[i];}
function needsNatural(li,i,si=0,p=project()){
 const l=p.lines[li],pitch=l?.melody?.[i]?.[si]?.p??l?.pitches[i];
 if(pitch===null||pitch===undefined)return false;
 const own=noteAlter(l,i,si);if(own===0)return false;
 if(own===1||own===-1)return true;
 for(const m of measureModel(p)){
  let previous=studioKeyAccidentals(p).get(pitch%7)||0;
  for(const n of m.notes){
   if(n.li===li&&n.i===i&&(n.si??0)===si&&n.first)return previous!==0||scorePitchAlter(pitch,p)!==0;
   if(!n.rest&&n.p===pitch&&n.first)previous=n.alter??scorePitchAlter(n.p,p);
  }
 }
 return scorePitchAlter(pitch,p)!==0;
}
function accidentalNoteCount(p=project()){
 return p.lines.reduce((sum,l)=>sum+l.pitches.reduce((n,pitch,i)=>n+(l.melody?.[i]||[{p:pitch,alter:l.accidentals?.[i]}]).filter(part=>!part.rest&&part.p!==null&&[1,-1].includes(part.alter)).length,0),0);
}
function accidentalProgressText(p=project()){return `已加入 ${accidentalNoteCount(p)} 处升降号 · 至少 2 处`;}
function setNoteAlter(li,i,si,alter){
 const p=project(),l=p.lines[li];if(notePitch(li,i,si)===null)return false;if(alter===0&&!needsNatural(li,i,si,p)){toast('此处不需要还原哦');return false;}
 if(l.melody?.[i]){if(alter===null)delete l.melody[i][si].alter;else l.melody[i][si].alter=alter;}
 else {l.accidentals??={};if(alter===null)delete l.accidentals[i];else l.accidentals[i]=alter;}
 if(p.level===25&&alter!==null){p.accidentalPractice??={};p.accidentalPractice[String(alter)]=true;}
 return true;
}
function accidentalPracticeDone(p=project()){return accidentalNoteCount(p)>=2;}
function openNoteOptions(li,i,si=0){
 const p=project();if(p.level!==0&&p.level<4)return;
 const l=p.lines[li],part=l.melody?.[i]?.[si],on=part?part.staccato:l.staccato?.[i],m=$('#modal'),enabled=p.level===0||p.level>=25;
 m.innerHTML=`<h2>「${esc(lyricUnits(l.text)[i])}」的音符</h2><div class="choices">${enabled?[[1,'♯ 升号'],[-1,'♭ 降号'],...(p.level===0||p.level>=27?[[0,'♮ 还原号']]:[])].map(([a,label])=>`<button data-note-alter="${a}" aria-pressed="${noteAlter(l,i,si)===a}">${label}</button>`).join('')+'<button id="clearAlter">跟随调式</button>':''}<button id="toggleNoteStaccato">${on?'移除':'添加'}跳音</button></div>${enabled?'<p class="hint">升号：把本位音升高半音；降号：降低半音。可以试听后再换。</p>':''}<div class="actions"><button id="closeNoteOptions">返回乐谱</button></div>`;
 const done=()=>{m.close();stop();refreshScore();if(p.level===4&&p.step===(sentenceLesson(p)?3+p.lines.length:6)&&$('#next'))$('#next').disabled=!staccatoDone();const e=lineEvents(l).find(e=>e.i===i&&e.si===si&&!e.rest);if(e)playEvents([{...e,t:0,d:.7}]);};
 $$('[data-note-alter]').forEach(b=>b.onclick=()=>{const alter=+b.dataset.noteAlter;if(alter===0&&!needsNatural(li,i,si)){toast('此处不需要还原哦');return;}mutate(()=>setNoteAlter(li,i,si,alter));done();});
 if($('#clearAlter'))$('#clearAlter').onclick=()=>{mutate(()=>setNoteAlter(li,i,si,null));done();};
 $('#toggleNoteStaccato').onclick=()=>{mutate(()=>{if(part)part.staccato=!on;else{l.staccato??=l.pitches.map(()=>false);l.staccato[i]=!on;}});done();};
 $('#closeNoteOptions').onclick=()=>m.close();m.showModal();
}
function renderAccidentalLesson(){
 const p=project();$('#stage').innerHTML=heading('添加升降号','换个音，听听有什么不同～','点击五线谱音符，可以给音添加升（#）降（b）记号，让那个音的音高升高或降低一点点。试试在曲子里选两个音加上升号或降号吧～')+`<p class="hint" id="accidentalProgress">${accidentalProgressText(p)}</p>`+editingControls()+`<div id="scoreArea">${advancedScoreHTML()}</div>`;bindPlayback();
 nav(true,'',()=>{if(!accidentalPracticeDone(p)){toast('给作品中的两处音符加入升号或降号即可');return;}const issue=validate(p);if(issue){toast(issue);return;}mutate(()=>p.complete=true);advanceAdvanced();});$('#next').disabled=!accidentalPracticeDone(p);
}
function installNewLessons(){
 const oldEvents=lineEvents,oldSteps=advancedSteps,oldRender=renderOrderedLesson,oldRefresh=refreshScore,oldCopy=copyPhraseData,oldSplit=applySplit,oldValid=validStudioData,oldBind=bindArticulation,oldGroups=sectionComposeGroupsHTML,oldLyrics=renderEditableLessonLyrics;
 lineEvents=function(l){return oldEvents(l).map(e=>{const alter=noteAlter(l,e.i,e.si);return !e.rest&&alter!==undefined?{...e,alter,explicitAccidental:true}:e;});};
 advancedSteps=function(p=project()){return oldSteps(p).map(s=>p.level===25&&s.kind==='review'?{kind:'accidentals',name:'添加升降号'}:s);};
 renderOrderedLesson=function(){if(project().level===25&&advancedStep().kind==='accidentals')return renderAccidentalLesson();return oldRender();};
 refreshScore=function(){oldRefresh();if(project().level===25&&advancedStep().kind==='accidentals'&&$('#next')){$('#next').disabled=!accidentalPracticeDone();if($('#accidentalProgress'))$('#accidentalProgress').textContent=accidentalProgressText();}};
 bindArticulation=function(){oldBind();if(project().level===0||project().level>=4)$$('.note').forEach(el=>el.oncontextmenu=e=>{e.preventDefault();openNoteOptions(+el.dataset.li,+el.dataset.i,+(el.dataset.si||0));});};
 copyPhraseData=function(from,to){oldCopy(from,to);to.accidentals={};for(const [i,a] of Object.entries(from.accidentals||{}))if(+i<to.pitches.length)to.accidentals[i]=a;};
 applySplit=function(li,i,ds){const l=project().lines[li],alters=(l.melody?.[i]||[{alter:l.accidentals?.[i]}]).map(n=>n.alter);oldSplit(li,i,ds);l.melody[i].forEach((n,j)=>{const a=alters[j]??alters[0];if(a!==undefined)n.alter=a;});if(l.accidentals)delete l.accidentals[i];};
 validStudioData=function(p){return oldValid(p)&&p.lines.every(l=>(!l.accidentals||Object.entries(l.accidentals).every(([i,a])=>Number.isInteger(+i)&&+i>=0&&+i<l.pitches.length&&[-1,0,1].includes(a)))&&Object.values(l.melody||{}).every(parts=>parts.every(n=>n.alter===undefined||[-1,0,1].includes(n.alter))));};
 sectionComposeGroupsHTML=function(state,p=project()){return ([24,29].includes(p.level)?'<p class="hint">一个发音音节对应一个位置，例如 Morn-ing 有两个音节，light 只有一个。这里的分隔线用来安排词组；要改音节，回到“编辑歌词与分段”，用 - 分开。</p>':'')+oldGroups(state,p);};
 renderEditableLessonLyrics=function(){oldLyrics();if([24,29].includes(project().level)){const input=$('#lessonLyrics');input.value=project().lyricsEditDraft??sectionText().split('\n').map(englishSyllableDraft).join('\n');const hint=document.createElement('p');hint.className='hint';hint.textContent='按发音划分音节，用 - 分开，例如 morn-ing。单词之间留空格；新增单词请手动确认音节，元音字母数不等于音节数。空一行可分段。';input.before(hint);}};
}
