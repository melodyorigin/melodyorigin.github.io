/* Numbered notation uses the major tonic represented by the key signature. */
function numberedKey(p=project()){
 const fifths=keySignatureFifths(p),letter=((fifths*4)%7+7)%7;
 const alter=studioKeyAccidentals(p).get(letter)||0;
 return {letter,label:(alter===1?'♯':alter===-1?'♭':'')+NAMES[letter]};
}
function numberedNote(n,p=project()){
 if(n.rest)return {text:'0',octave:0};if(n.p===null)return {text:'·',octave:0};
 const key=numberedKey(p),letter=((n.p%7)+7)%7,baseline=studioKeyAccidentals(p).get(letter)||0;
 const actual=n.alter??scorePitchAlter(n.p,p),delta=actual-baseline;
 const sign=delta===1?'♯':delta===-1?'♭':delta===2?'𝄪':delta===-2?'𝄫':n.alter===0&&baseline===0?'♮':'';
 return {text:sign+String(((letter-key.letter)+7)%7+1),octave:Math.floor((n.p-key.letter)/7)-4};
}
/* Shared engraving grid: rhythm, staff, lyric and numbered notation. */
function noteY(p){return 198-(p-30)*6;}
function glyph(name,x,y,scale=1,color='currentColor'){
  const g=MUSIC_GLYPHS[name];
  return `<path data-glyph="${name}" d="${g.path}" transform="translate(${x} ${y}) scale(${scale})" fill="${color}"/>`;
}
function lineBeats(l,p=project()){if(boundedLesson(p))return 2*barBeats(p);return Math.max(isTutorialRhythm(p)?8:barBeats(p),Math.ceil(l.durations.reduce((a,d)=>a+(d??1),0)/barBeats(p))*barBeats(p));}
function spellRhythm(t,d,bar=4){
  const [beats,denominator]=meterParts();
  const compound=denominator===8&&beats>=6&&beats%3===0;
  const beat=compound?1.5:4/denominator;
  const halfBar=beats===4||compound&&beats===6?bar/2:bar;
  const values=[4,3,2,1.5,1,.75,.5,.25];
  const parts=[];
  while(d>.0001){
    const pos=t%bar;
    // A sustained note starting between beats first completes that beat.
    // A note starting on a weak beat first completes its half of the bar.
    const offBeat=pos%beat;
    let room=bar-pos;
    if(offBeat)room=Math.min(room,beat-offBeat);
    else if(pos%halfBar)room=Math.min(room,halfBar-pos%halfBar);
    const ticks=Math.round(Math.min(d,room)*12);
    const value=ticks%3===0?values.find(v=>Math.round(v*12)<=ticks):
      [48,36,24,12,8,4,2,1].find(v=>v<=ticks)/12;
    if(!value)throw Error('无法分组的音符时值');
    parts.push({t,d:value});
    t=Math.round((t+value)*12)/12;
    d=Math.round((d-value)*12)/12;
  }
  return parts;
}
function measureModel(p){
  const measures=[],bar=barBeats(p);
  p.lines.forEach((l,li)=>{
    const total=lineBeats(l,p),base=measures.length;
    for(let b=0;b<total/bar;b++)measures.push({li,bar:b,number:base+b,notes:[]});
    lineEvents(l).forEach(e=>{
      spellRhythm(e.t,e.d,bar).forEach((part,k,parts)=>measures[base+Math.floor(part.t/bar)].notes.push({...e,...part,li,first:k===0,last:k===parts.length-1,rest:!!e.rest,local:part.t%bar}));
    });
    const end=lineEvents(l).reduce((a,e)=>Math.max(a,e.t+e.d),0);
    spellRhythm(end,total-end,bar).forEach(part=>measures[base+Math.floor(part.t/bar)].notes.push({...part,li,i:-1,rest:true,local:part.t%bar,first:false,last:false}));
  });
  return measures;
}
function systemModel(p,focusLi=null){
  const bars=[2,3,4,5,6,7,8].includes(p.barsPerRow)?p.barsPerRow:0,all=measureModel(p),focus=focusLi===null?null:(Array.isArray(focusLi)?focusLi:[focusLi]);let chunks=[];
  // Identify the complete measure before a focused view changes its phrase/bar.
  // In a pickup, one measure may contain the end and start of different phrases.
  all.forEach(m=>{m.layoutKey=`${m.li}:${m.bar}`;});
  // A pickup can place the start of a phrase in the preceding phrase's measure.
  // Focus by notes, so returning to a phrase editor never hides its first syllables.
  const measures=!focus?all:all.filter(m=>m.notes.some(n=>focus.includes(n.li))).map(m=>{
    const notes=m.notes.filter(n=>focus.includes(n.li));return {...m,notes,li:notes.find(n=>!n.rest)?.li??notes[0].li};
  });
  if(focus){const counts=new Map();measures.forEach(m=>{m.bar=counts.get(m.li)||0;counts.set(m.li,m.bar+1);});}
  if(p.barsPerRow==='auto-phrases'){const ids=[...new Set(measures.map(m=>m.li))];for(let i=0;i<ids.length;){const first=measures.filter(m=>m.li===ids[i]),next=i+1<ids.length?measures.filter(m=>m.li===ids[i+1]):[];if(next.length&&first.length+next.length<6){chunks.push([...first,...next]);i+=2;}else{chunks.push(first);i++;}}}
  else if(p.barsPerRow==='two-phrases'){const ids=[...new Set(measures.map(m=>m.li))];for(let i=0;i<ids.length;i+=2)chunks.push(measures.filter(m=>ids.slice(i,i+2).includes(m.li)));}
  else if(!bars){for(const li of [...new Set(measures.map(m=>m.li))])chunks.push(measures.filter(m=>m.li===li));}
  else for(let i=0;i<measures.length;i+=bars)chunks.push(measures.slice(i,i+bars));
  if(typeof scoreLayoutChunks==='function')chunks=scoreLayoutChunks(chunks,p);
  const layoutScope=focus===null?'all':`phrases:${[...new Set(focus)].sort((a,b)=>a-b).join(',')}`;
  // One time scale across systems. Make room for the densest lyric once,
  // so shorter notes and rests never acquire arbitrary extra time on screen.
  let beatWidth=52;
  for(const m of measures)for(const n of m.notes){
    const lyric=n.rest||n.syllableFirst===false?'':lyricUnits(p.lines[n.li].text)[n.i]||'';
    const space=/[A-Za-z]/.test(lyric)?lyric.length*11+22:25;
    beatWidth=Math.max(beatWidth,space/n.d);
  }
  // Reserve both sides of a group boundary before positioning any rhythm dots.
  const measureText=document.createElement('canvas').getContext('2d');
  measureText.font='20px '+(getComputedStyle(document.body).getPropertyValue('--lyric-font').trim()||'serif');
  const insets=p.lines.map(line=>lyricUnits(line.text).map((word,i,words)=>{
    const suffix=i===words.length-1?(line.punct||''):'';
    return Math.max(19,Math.ceil(measureText.measureText(word+suffix+'-').width/2)+4);
  }));
  for(const [li,line] of p.lines.entries()){
    const events=lineEvents(line).filter(n=>!n.rest&&n.syllableFirst!==false);
    events.forEach((n,i)=>{
      const next=events[i+1];
      if(!next)return;
      const boundary=line.cuts[next.i-1];
      const clearance=insets[li][n.i]+insets[li][next.i]+(boundary?4:0);
      beatWidth=Math.max(beatWidth,clearance/(next.t-n.t));
    });
  }
  const mm=96/25.4, beforeBar=mm, afterBar=2.5*mm;
  const restCellBeats=rhythmDragStep();
  const soundDurations=p.lines.map(line=>new Map(lineEvents(line).filter(e=>!e.rest).map(e=>[e.t,e.d])));
  const seenPhrases=new Set();
  const rows=chunks.map((row,rowIndex)=>{
    let cursor=92;
    row.forEach(m=>{
      m.x=cursor;
      const barStart=cursor-5;
      let x=barStart+afterBar+7; // measured from the left edge of the notehead
      for(const n of m.notes){
        n.x=x;
        const eighth=n.first&&soundDurations[n.li].get(n.t)===.5;
        const adjustment=n.rest?-mm*n.d/restCellBeats:(eighth ? 1.5*mm : 0);
        n.slot=n.d*beatWidth+adjustment;
        n.lyricInset=insets[n.li][n.i]??19;
        x+=n.slot;
      }
      cursor=x+beforeBar+5;
      m.width=cursor-m.x;
    });
    const next=chunks[rowIndex+1]?.[0],layoutNextMeasure=next?{key:next.layoutKey,number:next.number}:null;
    // A pickup can start the next phrase inside the preceding phrase's measure.
    const playLines=[];
    for(const measure of row)for(const note of measure.notes){
      if(!seenPhrases.has(note.li)){seenPhrases.add(note.li);playLines.push(note.li);}
    }
    return {measures:row,playLines,layoutScope,layoutNextMeasure,width:cursor+20,endX:cursor-5,first:row[0].number===0,showTimeSignature:row[0].number===0||!!focus&&rowIndex===0,last:row.at(-1).number===all.at(-1).number};
  });
  const uniform=Math.max(bars===2?660:1120,...rows.map(r=>r.width));rows.forEach(r=>r.width=uniform);return rows;
}
function writtenNoteDuration(d){
  return Math.round(d*12)%3 ? d*1.5 : d;
}
function eighthTriplet(group){
  return group.length===3&&group.every(n=>Math.round(n.d*12)===4);
}
function beamGroups(notes){
  const result=[];let group=[];const [num,den]=meterParts(),unit=den===8&&num>=6&&num%3===0?1.5:4/den;
  const flush=()=>{if(group.length>1)result.push(group);group=[];};
  notes.forEach(n=>{
    if(n.rest||writtenNoteDuration(n.d)>=1){flush();return;}
    const prev=group.at(-1);
    if(prev&&((writtenNoteDuration(prev.d)!==prev.d)!==(writtenNoteDuration(n.d)!==n.d)||Math.floor((prev.metric??prev.local??prev.t)/unit)!==Math.floor((n.metric??n.local??n.t)/unit)||prev.li!==n.li||Math.abs(prev.t+prev.d-n.t)>.001))flush();
    group.push(n);
  });flush();return result;
}
function head(d,x,y,color='currentColor',scale=1){
  const name=d>=4?'whole':d>=2?'half':'black',g=MUSIC_GLYPHS[name];
  return glyph(name,x-g.width*scale/2,y,scale,color);
}
function dot(d,x,y){return [3,1.5,.75].includes(d)?`<circle cx="${x+12}" cy="${y-3}" r="2.1" fill="currentColor"/>`:'';}
function stem(n,y,up,end,flag=true){
  if(n.d>=4)return '';
  const sx=n.x+(up?6:-6);let out=`<path d="M${sx} ${y}V${end}" stroke="currentColor" stroke-width="1.4"/>`;
  if(flag&&writtenNoteDuration(n.d)<1)out+=glyph((writtenNoteDuration(n.d)<.5?'flag16':'flag8')+(up?'Up':'Down'),sx,end,.78);
  return out;
}
function beatLabel(d){const whole=Math.floor(d),quarter=Math.round((d-whole)*4),fraction=['','1/4','1/2','3/4'][quarter];return d===.5?'半拍':`${whole||!quarter?whole:''}${whole&&quarter?'又':''}${fraction}拍`;}
function teachesRhythmDrag(p=project()){return p.level>=1 && p.level<=5;}
function rhythmLessonTape(li,playAttr,annotation=''){
 const l=project().lines[li];
 const tape=sentenceTape(li,groups(l).map(g=>'<button disabled class="rhythm-word">'+esc(g.text)+'</button>').join(''));
 return '<div class="rhythm-line lesson-tape-row"><button '+playAttr+'>▶ 播放整句</button>'+annotation+tape+'</div>';
}
const rhythmGuideText={
 pitch:"这里也能拖动节奏圆点",
 strip:'拖圆点，或点按微调',
 end:'拖双线，改尾音',
 padding:'空心点补足小节'
};
// Place each caption below its own target. Nearby captions use separate rows.
function anchoredRhythmGuides(points,width){
 if(project().level<1||project().level>5)return {height:0,svg:''};
 const boxes=[];
 for(const {kind,x} of points){
  if(!Number.isFinite(x))continue;
  const chars=Math.max(6,Math.min(13,Math.floor((width-16)/14)));
  const rows=rhythmGuideText[kind].match(new RegExp('.{1,'+chars+'}','gu'));
  const w=Math.min(chars,rhythmGuideText[kind].length)*14+8;
  const left=Math.max(4,Math.min(width-w-4,x-w/2));
  let top=10;
  for(const box of boxes)if(left<box.left+box.w+5&&left+w+5>box.left)top=Math.max(top,box.bottom+8);
  boxes.push({kind,x,left,w,top,bottom:top+rows.length*19,rows});
 }
 const svg=boxes.map(({kind,x,left,w,top,rows})=>{
  const lead=Math.max(left+5,Math.min(left+w-5,x));
  return `<g class="rhythm-caption ${kind==='padding'?'padding-guide':''}" data-caption="${kind}" pointer-events="none"><path d="M${x} 0 L${lead} ${top-2}" fill="none" stroke="#95a68d"/><rect x="${left}" y="${top}" width="${w}" height="${rows.length*19}" rx="4" fill="#fafaf3"/><text fill="#52654e" font-size="14" font-family="serif">${rows.map((r,i)=>`<tspan x="${left+4}" y="${top+15+19*i}">${r}</tspan>`).join('')}</text></g>`;
 }).join('');
 return {height:boxes.reduce((h,b)=>Math.max(h,b.bottom+6),0),svg};
}
function rhythmEnd(x,y,li,t,unit){
 return `<g class="rhythm-end" data-rhythm-end="${t}" data-dot-line="${li}" data-unit="${unit}"><title>拖动竖线调整最后一个字的时长</title><rect x="${x-13}" y="${y-13}" width="26" height="26" fill="transparent"/><path d="M${x-3} ${y-10}v20 M${x+1} ${y-10}v20" fill="none" stroke="#496b57" stroke-width="2" stroke-linecap="round"/></g>`;
}
function lyricEighthPairs(notes,line){
 const pairs=[];
 for(let j=1;j<notes.length;j++){
  const left=notes[j-1],right=notes[j];
  if(right.i!==left.i+1||line.cuts[left.i]||line.restsAfter?.[left.i])continue;
  if(line.durations[left.i]===.5&&line.durations[right.i]===.5&&right.t===left.t+.5){
   pairs.push([left,right]);j++;
  }
 }
 return pairs;
}
function sentenceTape(li,buttonHTML){
 const line=project().lines[li], events=lineEvents(line);
 const units=lyricUnits(line.text);
 const anchors=new Map();
 for(const event of events){
  if(!anchors.has(event.i)||event.syllableFirst)anchors.set(event.i,event);
 }
 // Leave room on both sides of a centered syllable, including English lyrics.
 const measure=document.createElement('canvas').getContext('2d');
 const family=getComputedStyle(document.body).getPropertyValue('--lyric-font').trim()||'serif';
 measure.font='18px '+family;
 const widths=units.map(word=>Math.ceil(measure.measureText(word).width));
 const innerMargin=96/25.4+2; // One CSS millimetre inside the selected card's 2px outline.
 const inset=innerMargin+widths.reduce((half,w)=>Math.max(half,w/2),9);
 let unit=events.some(n=>n.d<.5)?96:64;
 for(const event of events){
  const halfLabel=anchors.get(event.i)===event?widths[event.i]/2:0;
  const rightExtent=Math.max(halfLabel,14); // Includes the rightward flag or augmentation dot.
  if(event.d>0)unit=Math.max(unit,Math.ceil((inset+rightExtent+innerMargin)/event.d));
 }
 const total=lineBeats(line,project());
 const width=inset*2+unit*total;
 const template=document.createElement('template');
 template.innerHTML=buttonHTML;
 const buttons=[...template.content.querySelectorAll('button')];
 groups(line).forEach((group,index)=>{
  const button=buttons[index];
  if(!button)return;
  const members=events.filter(event=>event.i>=group.start&&event.i<group.end);
  const start=members[0]?.t??0,last=members.at(-1);
  const span=unit*(last?last.t+last.d-start:0);
  const syllables=members.filter(n=>anchors.get(n.i)===n&&!n.rest);
  const pairs=lyricEighthPairs(syllables,line),joined=new Set(pairs.flat());
  const symbols=syllables.map(n=>{
   const d=line.durations[n.i]??1;
   const x=inset+unit*(n.t-start);
   const lyric=anchors.get(n.i)===n
    ? `<text class="tape-syllable" x="${x}" y="24" text-anchor="middle">${esc(units[n.i])}</text>` : '';
   const note=n.assigned&&!n.rest
    ? `<g transform="translate(${x} 77) scale(.82)">${head(d,0,0)}${stem({...n,x:0,d},0,true,-30,!joined.has(n))}${dot(d,0,0)}</g>` : '';
   return lyric+note;
  }).join('')+pairs.map(([a,b])=>`<path d="M${inset+unit*(a.t-start)+6*.82} ${77-30*.82}H${inset+unit*(b.t-start)+6*.82}" stroke="currentColor" stroke-width="3.3"/>`).join('');
  button.setAttribute('aria-label',group.text);
  button.innerHTML=`<svg aria-hidden="true" width="${span}" height="90" viewBox="0 0 ${span} 90"><g color="#284638">${symbols}</g></svg>`;
  button.style.left=(unit*start)+'px';
  button.style.width=span+'px';
 });
 const segments=events.map(event=>({...event,x:inset+unit*event.t,end:inset+unit*(event.t+event.d),attack:event.assigned&&!event.rest,rest:event.rest||!event.assigned}));
 const end=events.reduce((time,event)=>Math.max(time,event.t+event.d),0);
 if(end<total)segments.push({x:inset+unit*end,end:inset+unit*total,d:total-end,attack:false,rest:true});

 const lastSound=events.findLast(event=>!event.rest);
 const endX=lastSound?inset+unit*(lastSound.t+lastSound.d):null;
 const pad=total-end;
 const guides=anchoredRhythmGuides([{kind:'strip',x:inset+unit*(events.find(e=>e.assigned&&!e.rest&&e.t>0)?.t??0)},{kind:'end',x:endX},{kind:'padding',x:pad>0?inset+unit*(end+Math.max(0,pad/2-.25)):null}],width);
 return `<div class="sentence-tape-scroll"><div class="sentence-tape" style="width:${width}px"><div class="tape-words">${template.innerHTML}</div><svg data-sentence-tape="${li}" data-unit="${unit}" data-inset="${inset}" width="${width}" height="${40+guides.height}" viewBox="0 51 ${width} ${40+guides.height}"><rect x="1" y="54" width="${width-2}" height="23" rx="9" fill="#eef3ec" stroke="#bdcbbb"/>${rhythmDotStrip(segments,65,rhythmDragStep(),()=>line)}${lastSound?rhythmEnd(inset+unit*(lastSound.t+lastSound.d),65,li,lastSound.t+lastSound.d,unit):''}<g transform="translate(0 91)">${guides.svg}</g></svg></div></div>`;
}
function rhythmDragStep(){return .5;}
function rhythmGridTick(line,tick){
 const beat=Math.floor(tick/12),offset=tick%12;
 if(line?.tripletBeats?.includes(beat))return offset%4===0;
 return offset%6===0||!!line?.quarterNodes?.includes(tick/12);
}
function rhythmDotStrip(events,y,step=rhythmDragStep(),nodesForLine=()=>null){
 let marks='',cursor=0;
 const triplets=new Map();

 for(const event of events){
  const start=event.t??cursor;
  const line=nodesForLine(event.li),first=Math.round(start*12),end=Math.round((start+event.d)*12);
  const offsets=[];
  for(let tick=first;tick<end;tick++){
   if(rhythmGridTick(line,tick)||(tick===first&&event.attack))offsets.push((tick-first)/12);
  }
  for(const [index,t] of offsets.entries()){
   const x=event.x+(event.end-event.x)*t/event.d;
   const onset=t===0&&event.attack;
   const tick=Math.round((start+t)*12),beat=Math.floor(tick/12);
   const quarter=tick%6!==0;
   if(line?.tripletBeats?.includes(beat)||tick%3!==0){
    const key=(event.li??0)+':'+beat;
    if(!triplets.has(key)){
      const base=events.find(e=>(e.li??0)===(event.li??0)&&e.t<=beat&&e.t+e.d>beat);
      triplets.set(key,{left:base?base.x+(base.end-base.x)*(beat-base.t)/base.d:x,right:x});
    }
    if(tick%4===0)triplets.get(key).right=x;
   }
   const chosen=onset&&line&&selectedRhythmOnset?.line===line&&selectedRhythmOnset.i===event.i&&selectedRhythmOnset.si===(event.si??0);
   marks+=`<circle ${chosen?'class="rhythm-dot-selected" ':''}data-onset="${onset}" data-dot-beat="${Math.round((start+t)*12)/12}" data-dot-length="${(offsets[index+1]??event.d)-t}" data-dot-line="${event.li??''}" cx="${x}" cy="${y}" r="${onset?5.4:3.5}" fill="${quarter?(onset?'#306fa6':'#b5c9d8'):onset?'#38705a':event.rest?'white':'#b4c6b9'}" stroke="#92ac9b" stroke-width=".6"/>`;
   if(line)marks+=`<ellipse class="rhythm-dot-halo" cx="${x}" cy="${y}" rx="9" ry="9" pointer-events="none" aria-hidden="true"/>`;
  }
  cursor+=event.d;
 }
 for(const {left,right} of triplets.values()){
  if(right<=left)continue;
  const mid=(left+right)/2;
  marks+=`<g class="rhythm-triplet-bracket" fill="#306fa6" pointer-events="none"><path d="M${left} ${y+9}v6H${mid-5} M${mid+5} ${y+15}H${right}v-6" fill="none" stroke="currentColor" color="#306fa6"/><text x="${mid}" y="${y+19}" text-anchor="middle" font-size="12">3</text></g>`;
 }
 return '<g class="rhythm-dot-strip" pointer-events="none">'+marks+'</g>';
}
function rhythmPreview(durations,labels=false){
  if(durations.some(d=>![.25,.5,.75,1,1.5,2,3,4].includes(d)))return extendedRhythmPreview(durations,labels);
  const notes=[];let t=0;
  durations.forEach((d,i)=>{notes.push({t,d,x:18+t*48,li:0,rest:false});t+=d;});
  let s=`<svg class="rhythm-preview" style="width:${Math.max(40,t*48+25)*.85}px;height:80px;max-width:none;flex:none" viewBox="0 -12 ${Math.max(40,t*48+25)} 94" xmlns="http://www.w3.org/2000/svg" aria-label="${durations.map(beatLabel).join('加')}"><g color="#284638">`;
  s+=rhythmDotStrip(notes.map(n=>({...n,end:n.x+n.d*48,attack:true})),-5);
  const beams=beamGroups(notes),beamed=new Set(beams.flat());
  notes.forEach((n,i)=>{s+=head(n.d,n.x,46)+stem(n,46,true,15,!beamed.has(n))+dot(n.d,n.x,46);if(labels)s+=`<text x="${n.x}" y="76" font-size="11" text-anchor="middle" fill="#7b8876">${n.d===2?'二分':n.d===4?'全音符':n.d===1.5?'附点四分':n.d===1?'四分':n.d<.5?'十六分':n.d===.75?'附点八分':'八分'}</text>`;});
  beams.forEach(g=>{
    s+=`<path class="preview-beam" d="M${g[0].x+6} 15H${g.at(-1).x+6}" stroke="currentColor" stroke-width="4"/>`;
    for(let j=0;j<g.length;j++)if(g[j].d<.5){const n=g[j],prev=g[j-1],next=g[j+1];
      if(next?.d<.5)s+=`<path class="preview-beam-secondary" d="M${n.x+6} 21H${next.x+6}" stroke="currentColor" stroke-width="3"/>`;
      else if(!(prev?.d<.5))s+=`<path class="preview-beam-secondary" d="M${n.x+6} 21h${next?12:-12}" stroke="currentColor" stroke-width="3"/>`;
    }
  });
  return s+'</g></svg>';
}
function phraseSlurRuns(notes){
  const runs=[];
  let run=[];
  function finish(){
    if(run.length>1)runs.push(run);
    run=[];
  }
  for(const note of notes){
    if(note.rest)continue;
    if(run.length&&note.li!==run[0].li)finish();
    if(note.staccato){
      if(run.length&&note.first)run.push(note);
      finish();
    }else run.push(note);
  }
  finish();
  return runs;
}
const rhythmNoteTransform='translate(0 30) scale(1 .82)';
function engravingSVG(row,mode='combined',editable=true){
  const p=project(),width=row.width,staff=mode!=='jianpu',numbers=mode!=='staff',combined=mode==='combined',height=combined?365:mode==='staff'?277:155;
  const lyricY=combined&&editable?24:staff?263:118,numY=staff?301:73;
  let s=`<svg class="score unified-score" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg" data-first-measure="${row.measures[0].number}" aria-label="${row.measures.map(m=>m.number+1).join('、')}小节乐谱"><rect width="${width}" height="${height}" fill="#fffefa"/><g font-family="Arial, PingFang SC, Microsoft YaHei, sans-serif" color="#263e35">`;
  if(staff&&row.first&&!editable&&mode==='staff')s+=`<g class="score-tempo" aria-label="四分音符每分钟 ${p.bpm} 拍"><g transform="translate(76 104) scale(1)">${head(1,0,0)}<path d="M6 0V-24" stroke="currentColor" stroke-width="1.4"/><text x="16" y="5" font-family="Georgia, Times New Roman, serif" font-size="20">= ${p.bpm}</text></g></g>`;
  if(combined&&editable){row.measures.forEach((m,i)=>{if(i&&row.measures[i-1].li!==m.li)s+=`<path class="phrase-divider" d="M${m.x-5} 0V82" stroke="#d8ddd3" stroke-width="1" pointer-events="none"/>`;});}
  if(staff){
    for(let j=0;j<5;j++)s+=`<line x1="15" x2="${row.endX}" y1="${150+j*12}" y2="${150+j*12}" stroke="#9fa89b" stroke-width=".8"/>`;
    s+=glyph('clef',24,186);
    if(row.first||editable&&row.showTimeSignature)s+=timeSignatureSVG(meterParts(p)[0],meterParts(p)[1]);
    if(combined)s+=`<text x="15" y="55" class="layer-label" font-size="14" fill="#899582">歌词节奏</text><text x="15" y="303" class="layer-label" font-size="14" fill="#899582">简谱</text>`;
  }else if(row.first||editable&&row.showTimeSignature){const [beats,unit]=meterParts(p);s+=`<g class="number-score-signature"><text x="18" y="24" font-size="13">1=${esc(numberedKey(p).label)}</text><text x="65" y="57" text-anchor="middle" font-size="19">${beats}</text><path d="M54 62H76" stroke="currentColor"/><text x="65" y="81" text-anchor="middle" font-size="19">${unit}</text></g><g class="score-tempo" transform="translate(100 24) scale(.8)">${head(1,0,0)}<path d="M6 0V-24" stroke="currentColor" stroke-width="1.4"/><text x="16" y="5" font-family="Georgia,serif" font-size="20">= ${p.bpm}</text></g>`;}
    const joinedLyricNotes=new Set();
    if(combined){
      const segments=row.measures.flatMap(m=>m.notes.map((note,i)=>({
        note, end:note.x+note.slot
      })));
      const sounding=segments.filter(({note})=>!note.rest);
      for(const li of new Set(sounding.map(({note})=>note.li)))for(const g of groups(p.lines[li])){
        const spans=sounding.filter(({note})=>note.li===li&&note.i>=g.start&&note.i<g.end);
        if(!spans.length)continue;
        const members=spans.map(({note})=>note).filter(n=>n.first&&n.syllableFirst!==false);
        const first=spans[0],last=spans.at(-1);
        const following=segments[segments.indexOf(last)+1]?.note;
        const groupX=first.note.x-first.note.lyricInset;
        const right=following&&!following.rest&&following.li===li
          ?following.x-following.lyricInset-4
          :last.end;
        const groupWidth=right-groupX;
        s+=`<rect class="rhythm-group-background" transform="${rhythmNoteTransform}" x="${groupX}" width="${groupWidth}" y="9" height="65" rx="8" fill="#edf2e6" pointer-events="none"/>`;
        for(const [left,right] of lyricEighthPairs(members,p.lines[li])){
          joinedLyricNotes.add(left);joinedLyricNotes.add(right);
          s+=`<path class="rhythm-beam" transform="${rhythmNoteTransform}" d="M${left.x+6} 24H${right.x+6}" stroke="currentColor" stroke-width="4" pointer-events="none"/>`;
        }
        const active=editable&&(p.level===0||inSentence(p)||p.level>=3||p.level===2&&(p.step===2||p.repeatFlow===2&&p.step>=0&&p.step<=2)),target=active&&p.level===2&&li===0&&g.start===0;
        s+=`<g class="lyric-group ${target?'task-target':''}" ${active?'role="button" tabindex="0"':''} data-rhythm-li="${li}" data-rhythm-i="${g.start}" aria-label="更改${esc(g.text)}的歌词节奏"><rect x="${groupX}" y="${lyricY-19}" width="${groupWidth}" height="29" rx="7" fill="${target?'#fff0c8':'#edf2e6'}" stroke="${target?'#c58c2c':'none'}"/></g>`;
      }
    }
  row.measures.forEach(m=>{
    const notes=m.notes,beams=beamGroups(notes),beamed=new Map();
    if(combined&&editable){s+=rhythmDotStrip(notes.map((n,i)=>({...n,end:n.x+n.slot,attack:!n.rest&&n.first})),98,rhythmDragStep(),li=>p.lines[li]);
      notes.forEach((n,i)=>{if(n.i<0||!n.last)return;const end=n.t+n.d,lastSound=lineEvents(p.lines[n.li]).findLast(event=>!event.rest);if(n.rest||!lastSound||end!==lastSound.t+lastSound.d)return;const right=n.x+n.slot;s+=rhythmEnd(right,98,n.li,end,(right-n.x)/n.d);});}
    beams.forEach(g=>{const up=g.reduce((sum,n)=>sum+(n.p??28),0)/g.length<34;const x0=g[0].x,dx=g.at(-1).x-x0,slope=dx?Math.max(-.12,Math.min(.12,(noteY(g.at(-1).p??28)-noteY(g[0].p??28))/dx)):0;const base=up?Math.min(...g.map(n=>noteY(n.p??28)-36-slope*(n.x-x0))):Math.max(...g.map(n=>noteY(n.p??28)+36-slope*(n.x-x0)));g.forEach(n=>beamed.set(n,{up,end:base+slope*(n.x-x0),slope}));});
    notes.forEach(n=>{
      const targetPitch=editable&&!n.rest&&isCadenceNote(p,n);
      const repair=editable&&!n.rest&&needsCopyRepair(p.lines[n.li],n.i,p);
      const targetRhythm=false;
      const chosen=editable&&selected?.li===n.li&&selected?.i===n.i&&(selected.si??0)===(n.si??0);
      if(combined&&!n.rest&&n.first&&n.syllableFirst!==false){
        const editRhythm=editable&&melodyEnabled(p);
        s+=`<g ${editRhythm?'role="button" tabindex="0"':''} transform="${rhythmNoteTransform}" class="lyric-rhythm ${targetRhythm?'task-target':''}" data-rhythm-li="${n.li}" data-rhythm-i="${n.i}" aria-label="${esc(lyricUnits(p.lines[n.li].text)[n.i])}的歌词节奏；${melodyEnabled(p)?'点击细分旋律节奏':'旋律拆分尚未解锁'}"><rect x="${n.x-19}" y="9" width="38" height="65" rx="8" fill="transparent" stroke="${targetRhythm?'#c58c2c':'none'}" stroke-width="2"/>`;
        const topD=p.lines[n.li].durations[n.i]??sectionComposeNoteDuration(p.lines[n.li],n.i,p);
        s+=head(topD,n.x,55,'currentColor',.92)+stem({...n,d:topD},55,true,24,!joinedLyricNotes.has(n))+dot(topD,n.x,55)+'</g>';
      }
      if(n.rest){
        if(staff){const name=n.d>=4?'restWhole':n.d>=2?'restHalf':n.d>=1?'restQuarter':n.d>=.5?'rest8':'rest16';const userRest=editable&&n.i>=0&&n.rest; s+=`<g class="rest ${userRest?'user-rest':''}" ${userRest?`role="button" tabindex="0" data-li="${n.li}" data-i="${n.i}" data-si="${n.si??0}" aria-label="${esc(lyricUnits(p.lines[n.li].text)[n.i])}后的休止，点击调整"`:''} color="#7d8977">${userRest?`<rect x="${n.x-17}" y="150" width="34" height="48" rx="5" fill="transparent"/>`:''}${glyph(name,n.x-5,174)}${dot(n.d,n.x+5,174)}</g>`;}
      }else if(staff){
        const hints=p.level===16?(editable&&dorianCadenceEnd(p,n)?endingPitches(p):[]):editable&&n.first?(p.level>0&&n.li===p.lines.length-1&&n.i===lyricUnits(p.lines[n.li].text).length-1?(curriculum(p)?endingPitches(p):[28,35]):curriculum(p)&&n.li===1&&n.i===lyricUnits(p.lines[1].text).length-1?Array.from({length:19},(_,i)=>25+i).filter(v=>middleDegrees(p).includes(v%7)&&modeAllowed(v,p)):p.level===2&&p.lines.length===4&&n.li===1&&n.i===4?[29,32,34,36]:[]):[];
        for(const pitch of hints){const gy=noteY(pitch);s+=`<g class="pitch-guide" pointer-events="none" opacity=".35" color="#738078">`;for(let ly=210;ly<=gy;ly+=12)s+=`<path d="M${n.x-12} ${ly}h24" stroke="currentColor"/>`;s+=head(n.d,n.x,gy,'currentColor',.92)+stem({...n},gy,pitch<34,gy+(pitch<34?-42:42))+`<text x="${n.x+17}" y="${gy+3}" font-size="9">${pname(pitch)}</text></g>`;}
        const y=noteY(n.p??28),beam=beamed.get(n),up=beam?.up??((n.p??28)<34),end=beam?.end??y+(up?-42:42);n.stemUp=up;n.stemEnd=end;
        s+=`<g class="${editable?'note':''} ${n.p===null?'pending':''} ${chosen?'selected':''} ${targetPitch?'task-target':''}" data-li="${n.li}" data-i="${n.i}" data-si="${n.si??0}" aria-label="${esc(lyricUnits(p.lines[n.li].text)[n.i])} ${n.p===null?'待定':pname(n.p)}" color="#263e35">`;
        if(repair)s+=`<ellipse class="copy-repair-note" cx="${n.x}" cy="${y}" rx="17" ry="13" fill="#fff1c7" fill-opacity=".4" stroke="#bd8524" stroke-width="2" pointer-events="none"/>`;
        if(editable)s+=`<rect x="${n.x-17}" y="112" width="34" height="137" fill="transparent"/>`;
        if(targetPitch)s+=`<rect class="cadence-target" aria-label="句末音高要求" pointer-events="none" x="${n.x-22}" y="${y-22}" width="44" height="52" rx="9" fill="none" stroke="#c58c2c" stroke-width="2"/>`;
        for(let ly=210;ly<=y;ly+=12)s+=`<path d="M${n.x-12} ${ly}h24" stroke="currentColor"/>`;
        for(let ly=138;ly>=y;ly-=12)s+=`<path d="M${n.x-12} ${ly}h24" stroke="currentColor"/>`;
        if(p.level!==0||n.p!==null){if(p.level===0&&studioAccidental(n.p))s+=`<text x="${n.x-23}" y="${y+5}" font-size="18">${studioAccidental(n.p)}</text>`;s+=head(n.d,n.x,y,'currentColor',.92)+stem(n,y,up,end,!beam)+dot(n.d,n.x,y);if(n.staccato&&n.first)s+=`<circle class="staccato-dot" cx="${n.x}" cy="${y+(up?12:-12)}" r="2.3" fill="currentColor"/>`;}
        if(editable&&n.first&&(p.level!==0||n.p!==null))s+=`<text class="pitch-name" x="${n.x}" y="${y+18}" text-anchor="middle" font-size="9" fill="#9ca697">${n.p===null?'待定':pname(n.p)}</text>`;
        s+='</g>';
      }
      if(repair&&n.first&&n.syllableFirst!==false)s+=`<rect class="copy-repair-lyric" x="${n.x-17}" y="${lyricY-23}" width="34" height="32" rx="13" fill="none" stroke="#bd8524" stroke-width="2" pointer-events="none"/>`;
      if(n.first&&n.syllableFirst!==false&&!n.rest)s+=`<text class="lyric" pointer-events="none" data-lyric="${n.li}-${n.i}" x="${n.x}" y="${lyricY}" text-anchor="middle" font-size="20">${esc(lyricUnits(p.lines[n.li].text)[n.i])}${['begin','middle'].includes(lyricSyllabic(p.lines[n.li].text,n.i))?'-':''}${n.i===lyricUnits(p.lines[n.li].text).length-1?(p.lines[n.li].punct||''):''}</text>`;
      if(numbers){
        if(n.staccato&&n.first)s+=`<circle class="number-staccato" cx="${n.x}" cy="${numY-39}" r="2"/>`;
        const number=numberedNote(n,p);
        s+=`<text class="number-note" data-number="${n.li}-${n.i}" x="${n.x}" y="${numY}" text-anchor="middle" font-size="22">${number.text}</text>`;
        if(!n.rest&&n.p!==null){const oct=number.octave;for(let j=0;j<Math.abs(oct);j++)s+=`<circle cx="${n.x}" cy="${oct>0?numY-26-j*5:numY+18+j*5}" r="1.8"/>`;}
        s+=dot(n.d,n.x,numY-5);
        if(writtenNoteDuration(n.d)<1&&!beamed.has(n))s+=`<path d="M${n.x-8} ${numY+5}h16" stroke="currentColor" stroke-width="1.3"/>`;
        if(writtenNoteDuration(n.d)<.5)s+=`<path d="M${n.x-8} ${numY+10}h16" stroke="currentColor" stroke-width="1.3"/>`;
        for(let j=1;j<Math.floor(n.d);j++)s+=`<text x="${n.x+n.slot*j/n.d}" y="${numY}" text-anchor="middle" font-size="20">${n.rest?'0':'−'}</text>`;
      }
    });
    beams.forEach(g=>{
      const b=beamed.get(g[0]),a=g[0].x+(b.up?6:-6),z=g.at(-1).x+(b.up?6:-6);
      if(staff&&!(p.level===0&&g.every(n=>n.p===null)))s+=`<path class="staff-beam" d="M${a} ${b.end}L${z} ${beamed.get(g.at(-1)).end}" stroke="currentColor" stroke-width="4"/>`;
      if(numbers)s+=`<path class="number-beam" d="M${g[0].x-8} ${numY+5}H${g.at(-1).x+8}" stroke="currentColor" stroke-width="1.3"/>`;
      if(eighthTriplet(g)){
        const middle=(a+z)/2;
        const labelY=(b.end+beamed.get(g.at(-1)).end)/2+(b.up?-7:16);
        if(staff)s+=`<text class="triplet-number" x="${middle}" y="${labelY}" text-anchor="middle" font-size="14" font-style="italic">3</text>`;
        if(numbers)s+=`<text class="triplet-number" x="${(g[0].x+g.at(-1).x)/2}" y="${numY-34}" text-anchor="middle" font-size="13">3</text>`;
      }
      for(let j=0;j<g.length;j++)if(writtenNoteDuration(g[j].d)<.5){const n=g[j],next=g[j+1],prev=g[j-1],end=writtenNoteDuration(next?.d)<.5?next.x:writtenNoteDuration(prev?.d)<.5?n.x:n.x+(next?10:-10);if(writtenNoteDuration(prev?.d)<.5&&!(writtenNoteDuration(next?.d)<.5))continue;
        if(staff)s+=`<path d="M${n.x+(b.up?6:-6)} ${beamed.get(n).end+(b.up?6:-6)}L${end+(b.up?6:-6)} ${beamed.get(n).end+b.slope*(end-n.x)+(b.up?6:-6)}" stroke="currentColor" stroke-width="3"/>`;
        if(numbers&&writtenNoteDuration(next?.d)<.5)s+=`<path d="M${n.x-8} ${numY+10}H${end+8}" stroke="currentColor"/>`;
      }
    });
    const endX=m.x+m.width-5,final=row.last&&m===row.measures.at(-1);
    if(staff)s+=`<path class="barline" d="M${endX} 150V198${final?`M${endX-6} 150V198`:''}" stroke="currentColor" stroke-width=".9"/>${final?`<path d="M${endX} ${staff?150:numY-23}V${staff?198:numY+9}" stroke="currentColor" stroke-width="2.8"/>`: ''}`;
    if(numbers)s+=`<path d="M${endX} ${numY-23}V${numY+9}${final?`M${endX-6} ${numY-23}V${numY+9}`:''}" stroke="currentColor" stroke-width=".9"/>${final?`<path d="M${endX} ${numY-23}V${numY+9}" stroke="currentColor" stroke-width="2.8"/>`: ''}`;
  });
  const ns=row.measures.flatMap(m=>m.notes);
  phraseSlurRuns(ns).forEach(arr=>{
    const li=arr[0].li;
    if(staff&&!(p.level===0&&arr.every(n=>n.p===null))){
      const ys=arr.map(n=>noteY(n.p??28)),a=arr[0].x,b=arr.at(-1).x;
      if(arr.length<2||b<=a)return;
      const floor=(combined&&editable?263:lyricY)-30,ceiling=80,clearance=arr.some(n=>!n.first||!n.last)?24:12;
      const preferred=arr.filter(n=>(n.p??28)<34).length>=arr.length/2?1:-1;
      const candidate=dir=>{
        const edge=(n,y)=>n.d<4&&((dir===1&&!n.stemUp)||(dir===-1&&n.stemUp))?n.stemEnd+dir*8:y+dir*clearance;
        const start=edge(arr[0],ys[0]),end=edge(arr.at(-1),ys.at(-1));
        let bend=10;
        for(let j=1;j<arr.length-1;j++){const t=(arr[j].x-a)/(b-a),line=start+(end-start)*t;const needed=dir*(edge(arr[j],ys[j])-line);bend=Math.max(bend,needed/Math.max(.3,4*t*(1-t)));}
        return {start,end,control:(start+end)/2+dir*2*Math.min(24,bend)};
      };
      let curve=candidate(preferred);
      // Put wide, low phrases above the notes instead of stretching into the lyrics.
      if(preferred===1&&Math.max(curve.start,curve.end,curve.control)>floor)curve=candidate(-1);
      const constrain=y=>Math.max(ceiling,Math.min(floor,y));
      const y1=constrain(curve.start),y2=constrain(curve.end),control=constrain(curve.control);
      s+=`<path class="phrase-slur" data-phrase="${li}" d="M${a} ${y1}Q${(a+b)/2} ${control} ${b} ${y2}" fill="none" stroke="#74856b" stroke-width="1.2" pointer-events="none"/>`;
    }
  });
  ns.forEach((n,i)=>{if(n.rest||n.last||p.level===0&&n.p===null)return;const next=ns[i+1],end=next&&!next.rest&&next.li===n.li&&next.i===n.i&&next.si===n.si?next.x-8:row.endX;if(staff){const y=noteY(n.p??28)+10;s+=`<path class="tie" d="M${n.x+7} ${y}Q${(n.x+end)/2} ${y+12} ${end} ${y}" fill="none" stroke="currentColor"/>`;}if(numbers)s+=`<path d="M${n.x+6} ${numY-27}Q${(n.x+end)/2} ${numY-41} ${end} ${numY-27}" fill="none" stroke="currentColor"/>`;});
  // Continuation ties after a system break.
  if(ns[0]&&!ns[0].rest&&!ns[0].first){const n=ns[0],y=noteY(n.p??28)+10;if(staff)s+=`<path d="M90 ${y}Q${(90+n.x)/2} ${y+10} ${n.x-7} ${y}" fill="none" stroke="currentColor"/>`;}
  if(combined&&editable&&p.level>0){
    const last=ns.find(n=>n.li===p.lines.length-1&&n.i===lyricUnits(p.lines[n.li].text).length-1&&n.first);
    if(last)s+=`<text class="ending-help" font-weight="600" x="${Math.max(160,Math.min(width-160,last.x))}" y="122" text-anchor="middle" font-size="12" fill="#64765b">${curriculum(p)?(p.tonic==='A'?'之前我们一直是C调，所以结束在C，现在是A调所以结束在A音':'现在是'+esc(studioModeLabel(p))+'，乐曲结束要回到'+esc(p.tonic||'C')+'音哦'):'现在是C大调，乐曲结束要回到C音哦'}</text>`;
    const middle=(curriculum(p)?middleDegrees(p).length:p.level===2)&&p.lines.length===4?ns.find(n=>n.li===1&&n.i===lyricUnits(p.lines[1].text).length-1&&n.first):null;
    if(middle){const x=Math.max(190,Math.min(width-190,middle.x));s+=`<text class="middle-help" font-weight="600" x="${x}" y="96" text-anchor="middle" font-size="12" fill="#64765b"><tspan x="${x}">${curriculum(p)&&p.tonic==='A'?'乐曲中间的休息，':'C大调里，我们乐曲中间的休息，'}</tspan><tspan x="${x}" dy="17">${curriculum(p)&&p.tonic==='A'?'试试停在 '+middleDegrees(p).map(d=>NAMES[d]).join('／')+' 的位置⬇️':'停留在G/D/B的位置会有停而未歇的感觉⬇️，快试试吧'}</tspan></text>`;}
  }
  if(combined&&editable&&p.level===4&&p.step===(sentenceLesson(p)?3+p.lines.length:6)){
    const targets=ns.filter(n=>n.li===1&&n.i<4&&n.first&&!n.rest);
    for(const n of targets)s+=`<ellipse class="staccato-pen" cx="${n.x}" cy="${noteY(n.p??28)}" rx="11" ry="9" fill="none" stroke="#a03e55" stroke-width="1.5" pointer-events="none"/>`;
    const first=targets.find(n=>n.i===0);
    if(first)s+=`<g pointer-events="none" fill="#a03e55"><path d="M${first.x} 126V${noteY(first.p??28)-12}" stroke="#a03e55" stroke-dasharray="3 3"/><text x="${Math.min(first.x,row.endX-230)}" y="124" font-size="14">右键音符加跳音点，再播放听听。</text></g>`;
  }
  if(combined&&editable&&p.level===2){
    if(!sentenceLesson(p)&&p.step===2){const first=ns.find(n=>n.li===0&&n.i===0&&n.first);if(first){const x=first.x;s+=`<g class="inline-help" pointer-events="none"><path d="M${x-25} 341V278l5 5m-5-5l-5 5" fill="none" stroke="#85937a"/><text x="${x-12}" y="350" font-size="15" font-weight="600" fill="#365b45">点击已拆分好的歌词，调整歌词节奏</text></g>`;}}

  }
  if(combined&&editable&&splitReview(p)){
    const targets=row.measures.flatMap(m=>m.notes).filter(n=>n.li===0&&!n.rest&&n.first&&n.syllableFirst!==false);
    if(targets.length){const left=targets[0].x-24,right=targets.at(-1).x+24;
      s+=`<g class="split-teaching-target" pointer-events="none"><rect x="${left}" y="5" width="${right-left}" height="75" rx="9" fill="none" stroke="#b88730" stroke-width="2"/>`;
      if(targets[0].i===0)s+=`<text x="${left}" y="102" font-size="14" fill="#72521d">点击歌词节奏的音符，可将音符拆成多个音，拆分后可调整它们的音高。</text>`;
      s+='</g>';
    }
  }
  const currentLine=inSentence(p)?sentenceIndex(p):0;
  const pitchStage=!inSentence(p)||p.sentenceStages[currentLine]===2;
  if(editable&&combined&&pitchStage&&teachesRhythmDrag(p)&&row.measures.some(m=>m.notes.some(n=>n.li===currentLine&&n.t===0&&!n.rest))){
    const template=document.createElement('template');
    template.innerHTML=s+'</g></svg>';
    const svg=template.content.firstElementChild;
    const dots=[...svg.querySelectorAll('.rhythm-dot-strip circle')];
    const attacks=dots.filter(d=>d.dataset.onset==='true'&&Number(d.dataset.dotLine)===currentLine);
    const anchor=attacks[1]||attacks[0];
    const points=[{kind:'pitch',x:Number(anchor?.getAttribute('cx')??NaN)}];
    const guides=anchoredRhythmGuides(points,row.endX+10);
    if(guides.height){
     svg.setAttribute('viewBox',`0 ${-guides.height} ${width} ${height+guides.height}`);
     const layers=svg.querySelectorAll('.lyric,.lyric-group,.rhythm-group-background,.lyric-rhythm,.rhythm-beam,.rhythm-dot-strip,.rhythm-end,.phrase-divider,.lyric-rhythm-reminder,.copy-repair-lyric,.layer-label[y="55"]');
     for(const el of layers){
      const wrapper=svg.ownerDocument.createElementNS(svg.namespaceURI,'g');
      wrapper.setAttribute('transform',`translate(0 ${-guides.height})`);
      el.before(wrapper);wrapper.append(el);
     }
     return svg.outerHTML.replace('</svg>',`<g transform="translate(0 ${111-guides.height})">${guides.svg}</g></svg>`);
    }
  }
  return s+'</g></svg>';
}
function phraseControls(row,editable=true){return [...new Set(row.measures.map(m=>m.li))].map(li=>{const ms=row.measures.filter(m=>m.li===li),start=ms[0].x,end=ms.at(-1).x+ms.at(-1).width;return `<div class="phrase-control-slot" data-phrase-controls="${li}" style="left:${start/row.width*100}%;width:${(end-start)/row.width*100}%">${phraseButtons(li,editable)}</div>`;}).join('');}
function scoreRowHTML(row,editable=true,label=''){
  const title=label||`第 ${row.measures[0].number+1}—${row.measures.at(-1).number+1} 小节`;
  const playButtons=row.playLines.map(li=>`<button type="button" data-play-line="${li}" aria-label="播放第 ${li+1} 句">▶ 第 ${li+1} 句</button>`).join('');
  const editTools=editable?phraseControls(row,true):'';
  return `<div class="score-system" data-score-phrases="${row.measures.map(m=>`${m.li}:${m.x}:${m.width}`).join(',')}">
    <div class="system-meta"><span>${title}</span>${playButtons?`<div class="score-line-playback">${playButtons}</div>`:''}</div>
    <div class="score-row-controls"></div>
    <div class="score-scroll score-viewport"><div class="score-layer-labels" aria-label="乐谱区域"><span data-score-layer="rhythm">歌词节奏</span><span data-score-layer="number">简谱</span></div><div class="score-sheet" data-score-width="${row.width}" data-score-content-width="${Math.min(row.width,Math.ceil(row.endX+25))}">${editTools?`<div class="phrase-control-track">${editTools}</div>`:''}${engravingSVG(row,'combined',editable)}</div></div><!--score-viewport-end--><div class="score-row-guidance" aria-label="本行乐谱提示"></div></div>`;
}
// UI text stays in normal HTML flow; only the engraved music is scaled.
function prepareScorePresentation(viewport,sheet){
 const system=viewport.closest?.('.score-system');if(!system)return;
 const host=system.querySelector('.score-row-controls'),track=sheet.querySelector('.phrase-control-track');
 if(host&&track)host.append(track);
 const svg=sheet.querySelector('svg.unified-score'),guidance=system.querySelector('.score-row-guidance');
 if(!svg||!guidance||svg.dataset.readableHints==='true')return;
 const phrases=(system.dataset.scorePhrases||'').split(',').filter(Boolean).map(item=>item.split(':').map(Number));
 const specs=[
  ['ending-help','句末提示','text.ending-help'],['middle-help','句中提示','text.middle-help'],
  ['scale-cadence-help','段落结尾','text.scale-cadence-help'],['section-opening-hint','段落开头','text.section-opening-hint'],
  ['strong-beat-hint','强拍提示','text.strong-beat-hint'],['inline-help','操作提示','text.inline-help,.inline-help text'],
  ['lyric-rhythm-reminder','歌词','.lyric-rhythm-reminder text'],['split-teaching-target','歌词节奏','.split-teaching-target text'],
  ['rest-teaching-label','休止提示','.rest-teaching-label text'],['review-barline-hint','小节线','.review-barline-hint text'],
  ['review-cadence-help','段末要求','text.review-cadence-help'],['cadence-label','句末要求','text.cadence-label'],
  ['bar-drag-help','小节线','text.bar-drag-help'],['natural-teaching-help','还原记号','text.natural-teaching-help']
 ];
 const ink={
  'inline-help':'#704791','split-teaching-target':'#875117','rest-teaching-label':'#875117',
  'natural-teaching-help':'#98434e','bar-drag-help':'#286b80','review-barline-hint':'#286b80',
  'ending-help':'#416c58','middle-help':'#416c58','cadence-label':'#98434e'
 };
 for(const [kind,,selector] of specs)for(const source of svg.querySelectorAll(selector)){
  source.style.fill=ink[kind]||'#526c48';
  source.style.fontWeight='600';
 }
 svg.dataset.readableHints='true';
}
function scoreDisplayWidth(sheet,available){
 const naturalWidth=Number(sheet.dataset.scoreWidth)||available,svg=sheet.querySelector?.('svg.unified-score');
 if(!svg)return naturalWidth;
 const original=svg.dataset.scoreFullViewBox||svg.getAttribute('viewBox');if(!original)return naturalWidth;
 const box=original.trim().split(/\s+/).map(Number);if(box.length!==4||!box.every(Number.isFinite))return naturalWidth;
 svg.dataset.scoreFullViewBox=original;
 const contentWidth=Number(sheet.dataset.scoreContentWidth),displayWidth=available<=640&&contentWidth>0?Math.min(naturalWidth,contentWidth):naturalWidth;
 // Only the live preview is cropped; engraving/export and all note coordinates stay intact.
 const viewBox=[box[0],box[1],displayWidth,box[3]].join(' ');
 if(svg.getAttribute('viewBox')!==viewBox)svg.setAttribute('viewBox',viewBox);
 return displayWidth;
}
function alignScoreControls(viewport,labelWidth,available,widthRatio=1){
 const system=viewport.closest?.('.score-system'),host=system?.querySelector('.score-row-controls');if(!host)return;
 const origin=system.querySelector('.system-meta')?.getBoundingClientRect?.(),bounds=viewport.getBoundingClientRect?.();
 const offset=origin&&bounds?Math.max(0,bounds.left-origin.left):0;
 host.style.marginLeft=offset+labelWidth+'px';host.style.width=available+'px';
 const track=host.querySelector?.('.phrase-control-track');if(!track)return;
 const slots=[...track.querySelectorAll('.phrase-control-slot')].map(slot=>({slot,left:parseFloat(slot.style.left)*widthRatio,width:parseFloat(slot.style.width)*widthRatio})).filter(({left,width})=>Number.isFinite(left)&&Number.isFinite(width));
 // Use one action layout across neighboring phrases; independent wrapping
 // otherwise moves a short phrase's regroup/transpose buttons onto other rows.
 track.dataset.compactTools=String(slots.some(({width})=>width*available/100<440));
 // Give a copy control its own row when its score column is narrower than its contents.
 track.toggleAttribute('data-stack-copy', slots.some(({slot, width}) => {
   const controls = slot.querySelectorAll('.copy-phrase');
   const columnWidth = width * available / 100;
   return Array.from(controls).some(control => control.scrollWidth + 8 > columnWidth);
 }));
 const edge=n=>Math.round(Math.max(0,Math.min(100,n))*1e8)/1e8;
 const boundaries=[...new Set([0,100,...slots.flatMap(({left,width})=>[edge(left),edge(left+width)])])].sort((a,b)=>a-b);
 track.style.gridTemplateColumns=boundaries.slice(1).map((end,i)=>(end-boundaries[i])+'%').join(' ');
 for(const {slot,left,width} of slots)slot.style.gridColumn=`${boundaries.indexOf(edge(left))+1} / ${boundaries.indexOf(edge(left+width))+1}`;
}
// SVG pointer handlers use the displayed bounding box, so editing stays aligned.
let scoreFitObserver=null;
function fitScoreViewport(viewport){
 const sheet=viewport.querySelector('.score-sheet');if(!sheet||!viewport.clientWidth)return;
 prepareScorePresentation(viewport,sheet);
 const labels=viewport.closest?.('.score-system')?viewport.querySelector('.score-layer-labels'):null,labelWidth=labels?.offsetWidth||0,available=viewport.clientWidth-labelWidth;if(available<=0)return;
 const displayWidth=scoreDisplayWidth(sheet,available);
 alignScoreControls(viewport,labelWidth,available,(Number(sheet.dataset.scoreWidth)||displayWidth)/displayWidth);
 sheet.style.marginLeft=labelWidth+'px';
 let width=Math.max(available,displayWidth);
 sheet.style.width=width+'px';
 const controls=[...sheet.querySelectorAll('.phrase-control-slot')];
 const ratio=Math.max(1,...controls.map(slot=>slot.clientWidth?Math.max(slot.scrollWidth,...[...slot.children].map(child=>child.scrollWidth))/slot.clientWidth:1));
 if(ratio>1.01){width=Math.ceil(width*ratio);sheet.style.width=width+'px';}
 const scale=available/width;
 sheet.style.transform=`scale(${scale})`;
 viewport.style.height=Math.ceil(sheet.offsetHeight*scale)+'px';
 if(labels){const number=labels.querySelector('[data-score-layer="number"]'),rhythm=labels.querySelector('[data-score-layer="rhythm"]');if(number){const top=Math.max((rhythm?.offsetHeight||24)+8,(287-(sheet.querySelector('svg')?.viewBox.baseVal.y||0))*available/displayWidth);number.style.top=top+'px';viewport.style.height=Math.ceil(Math.max(sheet.offsetHeight*scale,top+number.offsetHeight))+'px';}}
}
function bindScoreFit(){
 scoreFitObserver?.disconnect();scoreFitObserver=null;
 const viewports=[...$$('.score-viewport')];viewports.forEach(fitScoreViewport);
 if(!viewports.length||typeof ResizeObserver==='undefined')return;
 scoreFitObserver=new ResizeObserver(()=>viewports.filter(v=>v.isConnected).forEach(fitScoreViewport));
 viewports.forEach(viewport=>{scoreFitObserver.observe(viewport);scoreFitObserver.observe(viewport.querySelector('.score-sheet'));});
}
function scoreHTML(editable=true){return systemModel(project()).map(row=>scoreRowHTML(row,editable)).join('');}
function layoutControl(){const value=project().barsPerRow||0;const option=n=>`<button type="button" data-layout-bars="${n}" aria-pressed="${value===n}" class="${value===n?'active':''}">${n} 小节</button>`;return `<details class="layout-control"><summary>乐谱换行 · ${value==='auto-phrases'?'按乐句自动划分':value==='two-phrases'?'两句一行':value?value+' 小节':'一句一行'} ▾</summary><div class="layout-menu"><button type="button" data-layout-bars="auto-phrases" aria-pressed="${value==='auto-phrases'}" class="${value==='auto-phrases'?'active':''}">按乐句自动划分</button><button type="button" data-layout-bars="two-phrases" aria-pressed="${value==='two-phrases'}" class="${value==='two-phrases'?'active':''}">两句一行</button><button type="button" data-layout-bars="0" aria-pressed="${value===0}" class="${value===0?'active':''}">一句一行</button><div class="layout-options"><div>${[4,6,8].map(option).join('')}</div><div>${[2,3,5,7].map(option).join('')}</div></div></div></details>`;}

let activeScoreDragCancel=null;
function selectScoreNote(n){
 const {li,i,si}=n.dataset;
 clearRhythmOnset();
 selected={li:+li,i:+i,si:+(si||0)};
 $$('.note.selected').forEach(note=>note.classList.remove('selected'));
 // Tied fragments all edit the same sounding note.
 $$(`.note[data-li="${li}"][data-i="${i}"][data-si="${si||0}"]`).forEach(note=>note.classList.add('selected'));
}
function beginScoreNoteDrag(e,n,placement=null){
 if(e.button!==0)return;
 activeScoreDragCancel?.();
 e.preventDefault();
 const wasSelected=n.classList.contains('selected'),p=project(),pointerId=e.pointerId;
 const scale=n.getScreenCTM()?.d;
 if(!scale)return;
 selectScoreNote(n);
 const {li,i,si}=selected,initial=notePitch(li,i,si);
 const old=(wasSelected?initial:placement)??initial??snapModePitch(28),startY=e.clientY;
 let last=initial,changed=false,moved=false;
 function setPitch(pitch){
  if(pitch===last||!allowed(li,i,pitch))return;
  if(!changed){undo.push(JSON.stringify(p));if(undo.length>100)undo.shift();redo=[];changed=true;}
  setNotePitch(li,i,si,pitch);last=pitch;refreshScore();
 }
 function cleanup(){
  window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',up);
  window.removeEventListener('pointercancel',cancel);window.removeEventListener('blur',cancel);
  if(activeScoreDragCancel===cancel)activeScoreDragCancel=null;
 }
 function cancel(ev){
  if(ev?.pointerId!==undefined&&ev.pointerId!==pointerId)return;
  cleanup();if(changed&&project()===p)save();
 }
 function move(ev){
  if(ev.pointerId!==pointerId)return;
  if(project()!==p){cancel();return;}
  const dy=startY-ev.clientY;
  if(!moved&&Math.abs(dy)<3)return;
  moved=true;setPitch(snapModePitch(old+Math.round(dy/(6*scale))));
 }
 function up(ev){
  if(ev.pointerId!==pointerId)return;
  if(project()!==p){cancel();return;}
  cleanup();
  if(!moved&&(placement!==null||last===null))setPitch(placement??old);
  if(changed)save();
  refreshScore();
  if(last!==null)audition(last);
  if(wasSelected&&placement===null&&!moved&&!changed&&n.oncontextmenu)openNoteOptions(li,i,si);
 }
 if(placement!==null&&!wasSelected)setPitch(placement);
 activeScoreDragCancel=cancel;
 window.addEventListener('pointermove',move);window.addEventListener('pointerup',up);
 window.addEventListener('pointercancel',cancel);window.addEventListener('blur',cancel);
}
function bindScore(){
  bindScoreFit();bindStaffInput();bindArticulation();
  $$('[data-regroup-line]').forEach(b=>b.onclick=()=>openPhraseGroups(+b.dataset.regroupLine));
  $$('[data-play-line]').forEach(b=>b.onclick=()=>playAll(false,+b.dataset.playLine));
  $$('[data-layout-bars]').forEach(button=>button.onclick=()=>{mutate(()=>{project().barsPerRow=['auto-phrases','two-phrases'].includes(button.dataset.layoutBars)?button.dataset.layoutBars:+button.dataset.layoutBars;project().layoutVersion=4;});render();});
  $$('.note').forEach(n=>{n.onpointerdown=e=>beginScoreNoteDrag(e,n);});
  $$('.lyric-rhythm[role="button"]').forEach(el=>{el.onclick=()=>openMelodySplit(+el.dataset.rhythmLi,+el.dataset.rhythmI);el.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();el.onclick();}};});
  $$('.lyric-group[role="button"]').forEach(el=>{const open=()=>openRhythmEditor(+el.dataset.rhythmLi,+el.dataset.rhythmI);el.onclick=open;el.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();open();}};});
}
function refreshScore(){
  if($('#undo'))$('#undo').disabled=!undo.length;if($('#redo'))$('#redo').disabled=!redo.length;
  const area=$('#scoreArea');
  if(area){
    const html=area.dataset.complete==='true'?completedScoreHTML():scoreHTML(area.dataset.readonly!=='true');
    const demo=area.querySelector(':scope > [data-sentence-demo="pitch"][open]');
    if(demo){
      const template=document.createElement('template');template.innerHTML=html;
      const anchor=template.content.querySelector('[data-sentence-demo="pitch"]');
      if(anchor){
        // Keep the playing video and the height above the active note stable during a drag.
        for(const child of Array.from(area.children))if(child!==demo)child.remove();
        while(anchor.previousElementSibling)area.insertBefore(template.content.firstElementChild,demo);
        anchor.remove();area.append(template.content);
      }else area.replaceChildren(template.content);
    }else area.innerHTML=html;
    bindScore();
  }
  const sel=$('#selection');if(sel)sel.textContent=selected?`「${lyricUnits(project().lines[selected.li].text)[selected.i]}」 ${project().lines[selected.li].pitches[selected.i]===null?'待定':pname(project().lines[selected.li].pitches[selected.i])} · ↑↓ 调整音高`:'音高随时都可以通过拖动、点击、按上下键进行调整';
  updateTaskStatus();
}
function openRhythmEditor(li,i){
  if(project().level===0)return renderStudioRhythm(li,i);
  const p=project(),l=p.lines[li],g=groups(l).find(g=>i>=g.start&&i<g.end),current=l.durations.slice(g.start,g.end),opts=rhythmWindow(rhythmChoices(l,g),current,`${db.active}:${li}:${g.start}:${p.meter}`),m=$('#modal');
  m.innerHTML=`<div class="eyebrow">歌词节奏</div><h2>给「${esc(g.text)}」换一种长短</h2><p>改变每个字占用的时间，保留已经写好的音高。句末不足一小节会自动补休止符。</p>${rhythmBrowseHTML()}<div class="choices modal-choices">${opts.map((o,k)=>`<div class="choice ${JSON.stringify(o)===JSON.stringify(current)?'selected':''}" data-edit-option="${k}">${rhythmPreview(o,true)}<div class="option-actions"><button data-edit-play="${k}">▶ 试听</button><button data-edit-use="${k}" class="primary">${JSON.stringify(o)===JSON.stringify(current)?'当前':'使用'}</button></div></div>`).join('')}</div><div class="actions"><button id="cancelRhythm">返回乐谱</button></div>`;
  bindRhythmBrowse(()=>{m.close();openRhythmEditor(li,i);});
  $$('[data-edit-play]').forEach(b=>b.onclick=()=>previewPattern(opts[+b.dataset.editPlay],b));
  $$('[data-edit-use]').forEach(b=>b.onclick=()=>{const next=opts[+b.dataset.editUse];mutate(()=>next.forEach((d,j)=>{if(l.durations[g.start+j]!==d&&l.melody)delete l.melody[g.start+j];l.durations[g.start+j]=d;}));m.close();stop();refreshScore();toast('歌词节奏已更新，试听一下变化吧');});
  $('#cancelRhythm').onclick=()=>{stop();m.close();};m.showModal();
}
function previewPattern(ds,button){let t=0;playEvents(ds.map(d=>{const n={t,d,p:28};t+=d;return n;}),true,project().bpm,button?.closest('.choice')?.querySelector('.rhythm-preview'));}

function bindStaffInput(){
  $$('.unified-score').forEach(svg=>{
    if(!svg.querySelector('.note'))return;
    svg.classList.add('click-input');
    svg.addEventListener('pointerdown',e=>{
      if(e.button!==undefined&&e.button!==0)return;
      if(e.target.closest('.lyric-group,.lyric-rhythm,.rhythm-dot-strip,.rhythm-end,.bar-drag-handle,.user-rest')||rhythmControlAt(e))return;
      const matrix=svg.getScreenCTM();if(!matrix)return;
      const {x,y}=new DOMPoint(e.clientX,e.clientY).matrixTransform(matrix.inverse());
      const hit=e.target.closest('.note');
      if(hit&&e.target.tagName.toLowerCase()!=='rect')return;
      if(y<108||y>242)return;
      const candidates=(hit?[hit]:[...svg.querySelectorAll('.note')]).map(n=>({node:n,li:+n.dataset.li,i:+n.dataset.i,si:+(n.dataset.si||0),x:+n.querySelector('rect[fill="transparent"]').getAttribute('x')+17}));
      const nearest=candidates.reduce((a,b)=>Math.abs(a.x-x)<Math.abs(b.x-x)?a:b);
      if(Math.abs(nearest.x-x)>50)return;
      const old=notePitch(nearest.li,nearest.i,nearest.si);
      // Near a notehead, preserve normal click-to-select and dragging.
      if(e.target.closest('.note')&&Math.abs(y-noteY(old??28))<10)return;
      const pitch=snapModePitch(Math.round(30+(198-y)/6));if(!allowed(nearest.li,nearest.i,pitch))return;
      e.stopImmediatePropagation();beginScoreNoteDrag(e,nearest.node,pitch);
    },true);
  });
}

function completedScoreHTML(editCredits=false){
  const p=project(),lyricist=p.lyricist??(p.level?'孟浩然':'');
  const header=`<div class="sheet-heading"><h2>${editCredits?`<input id="workTitle" maxlength="80" aria-label="作品名称" value="${esc(p.title)}" placeholder="作品名称">`:esc(p.title)}</h2><div class="sheet-credits">${editCredits?`<label>作词：<input id="lyricistName" maxlength="40" value="${esc(lyricist)}" placeholder="作词者姓名"></label><label>作曲：<input id="composerName" maxlength="40" value="${esc(p.composer??'')}" placeholder="作曲者姓名"></label>`:`<div>作词：${esc(lyricist||'未署名')}</div><div>作曲：${esc(p.composer||'未署名')}</div>`}</div></div>`;
  return '<div class="completed-sheet">'+header+systemModel(project()).map(row=>engravingSVG(row,'staff',false).replace(`viewBox="0 0 ${row.width} 277"`,`viewBox="0 ${row.first?65:90} ${row.width} ${row.first?212:187}"`)).join('')+'</div>';
}

function extendedRhythmPreview(ds,labels){let t=0,notes=[];ds.forEach((d,i)=>{(d===2.5?(t%1===.5?[{t,d:.5},{t:t+.5,d:2}]:[{t,d:2},{t:t+2,d:.5}]):spellRhythm(t,d)).forEach((n,k,parts)=>notes.push({...n,word:i,first:k===0,last:k===parts.length-1,x:25+notes.length*35}));t+=d;});let s=`<svg class="rhythm-preview" viewBox="0 0 ${notes.length*35+35} 86" xmlns="http://www.w3.org/2000/svg"><g color="#284638">`;notes.forEach((n,i)=>{s+=head(n.d,n.x,46)+stem(n,46,true,10)+dot(n.d,n.x,46);if(!n.last)s+=`<path d="M${n.x+6} 55Q${n.x+17} 68 ${notes[i+1].x-6} 55" stroke="currentColor" fill="none"/>`;if(labels&&n.first)s+=`<text x="${n.x}" y="80" text-anchor="middle" font-size="10">${ds[n.word]}拍</text>`;});return s+'</g></svg>';}

function phraseButtons(li,editable=true){return `<div class="phrase-buttons">${editable?`<button data-regroup-line="${li}">调整第 ${li+1} 句歌词划分</button>`:''}</div>`;}
function openPhraseGroups(li){
  const p=project(),l=p.lines[li],draft=clone(l),m=$('#modal');
  function draw(){m.innerHTML=`<h2>调整第 ${li+1} 句歌词划分</h2><p class="hint">点击字之间的线来划分，每组 ${p.level? '1～2':'1～4'} 个字。</p><div class="groups-line">${lyricUnits(l.text).map((c,i)=>`<span class="character ${/[A-Za-z]/.test(c)?'english-syllable':''}">${esc(c)}</span>${i<l.cuts.length?`<button class="divider ${draft.cuts[i]?'on':''}" data-dialog-cut="${i}" aria-label="${esc(c)}后${draft.cuts[i]?'合并':'分组'}">│</button>`:''}`).join('')}</div><div class="actions"><button id="cancelGroups">取消</button><button id="saveGroups" class="primary">保存划分</button></div>`;
    $$('[data-dialog-cut]').forEach(b=>b.onclick=()=>{draft.cuts[+b.dataset.dialogCut]=!draft.cuts[+b.dataset.dialogCut];draw();});$('#cancelGroups').onclick=()=>m.close();$('#saveGroups').onclick=()=>{if(groups(draft).some(g=>g.end-g.start>(p.level?2:4))){toast(`请划分成每组最多 ${p.level?2:4} 个字`);return;}mutate(()=>{l.cuts=clone(draft.cuts);if(boundedLesson(p))normalizeLessonLine(l,p);});stop();m.close();render();};
  }draw();m.showModal();
}

function timeSignatureSVG(n,d){const digits=(value,y)=>{const chars=String(value).split(''),scale=chars.length>1?.72:1,width=chars.reduce((sum,c)=>sum+MUSIC_GLYPHS['time'+c].width,0)*scale;let x=76-width/2;return chars.map(c=>{const result=glyph('time'+c,x,y,scale);x+=MUSIC_GLYPHS['time'+c].width*scale;return result;}).join('');};return `<g class="time-signature" aria-label="${n}/${d} 拍">${digits(n,162)}${digits(d,186)}</g>`;}
