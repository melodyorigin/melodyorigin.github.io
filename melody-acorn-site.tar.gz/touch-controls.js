/* Touch gestures stay separate from desktop mouse editing. */
function installTouchControls(){
 let gesture=null,lastTap=null,suppressUntil=0,cancellingGesture=false;const fingers=new Set();
 const selector='.note,.lyric-rhythm[role="button"],.lyric-group[role="button"],.user-rest,[data-layout-bar],[data-drag-bar]';
 const key=el=>[el.classList.contains('note')?'note':el.classList.contains('lyric-group')?'group':el.classList.contains('lyric-rhythm')?'rhythm':'other',el.dataset.li,el.dataset.i,el.dataset.si,el.dataset.rhythmLi,el.dataset.rhythmI,el.dataset.layoutBar,el.dataset.dragBar].join(':');
 const cancel=()=>{if(gesture){clearTimeout(gesture.timer);if(gesture.changed&&gesture.project===project())save();}gesture=null;};
 document.addEventListener('pointerdown',e=>{
  if(e.pointerType!=='touch'){if(e.pointerType==='mouse'||e.pointerType==='pen'){cancel();lastTap=null;suppressUntil=0;}return;}fingers.add(e.pointerId);document.documentElement.classList.add('touch-input');
  if(fingers.size>1){
   e.stopImmediatePropagation();
   // Cancel delegated dragging without pretending a finger has left the screen.
   // Otherwise replacing one finger during a pinch can unexpectedly edit a note.
   cancellingGesture=true;
   try{window.dispatchEvent(new PointerEvent('pointercancel',{pointerId:gesture?.id??e.pointerId}));}finally{cancellingGesture=false;}
   cancel();lastTap=null;suppressUntil=Date.now()+700;return;
  }
  if(rhythmControlAt(e))return;
  const el=e.target.closest(selector);if(!el){if(e.target.closest('.unified-score'))e.stopImmediatePropagation();return;}
  if(typeof activeScoreDragCancel==='function')activeScoreDragCancel();
  e.stopImmediatePropagation();const note=el.classList.contains('note'),bar=el.hasAttribute('data-layout-bar')||el.hasAttribute('data-drag-bar');
  const g=gesture={el,note,bar,id:e.pointerId,x:e.clientX,y:e.clientY,moved:false,held:false,changed:false,down:e,context:el.oncontextmenu};
  if(note){
   e.preventDefault();selectScoreNote(el);
   Object.assign(g,selected);g.project=project();
   g.old=notePitch(g.li,g.i,g.si)??snapModePitch(28);g.last=g.old;
  }
  g.timer=setTimeout(()=>{if(gesture!==g||g.moved)return;g.held=true;lastTap=null;suppressUntil=Date.now()+800;if(!g.note&&g.context)g.context.call(el,new MouseEvent('contextmenu',{bubbles:true,cancelable:true,clientX:g.x,clientY:g.y}));},550);
 },true);
 window.addEventListener('pointermove',e=>{
  const g=gesture;if(!g||e.pointerId!==g.id)return;
  if(Math.hypot(e.clientX-g.x,e.clientY-g.y)<8&&!g.moved)return;
  clearTimeout(g.timer);g.moved=true;lastTap=null;if(g.held&&!g.note)return;
  if(g.note){
   if(g.project!==project()){cancel();return;}
   e.preventDefault();e.stopImmediatePropagation();
   // A fixed finger distance keeps pitch control usable even on a small score.
   const pitch=snapModePitch(g.old+Math.round((g.y-e.clientY)/12));
   if((pitch!==g.last||notePitch(g.li,g.i,g.si)===null)&&allowed(g.li,g.i,pitch)){
    if(!g.changed){undo.push(JSON.stringify(project()));if(undo.length>100)undo.shift();redo=[];g.changed=true;}
    setNotePitch(g.li,g.i,g.si,pitch);g.last=pitch;refreshScore();
   }
  }else if(g.bar&&!g.dragStarted){g.dragStarted=true;g.el.onpointerdown?.call(g.el,g.down);}
 },{capture:true,passive:false});
 window.addEventListener('pointerup',e=>{
  fingers.delete(e.pointerId);const g=gesture;if(!g||e.pointerId!==g.id)return;clearTimeout(g.timer);gesture=null;suppressUntil=Date.now()+700;
  if(g.dragStarted)return;
  e.stopImmediatePropagation();
  if(g.note&&g.project!==project())return;
  if(g.moved){if(g.note&&g.changed){save();refreshScore();audition(g.last);}return;}
  if(g.held){
   if(g.note&&g.context)g.context.call(g.el,new MouseEvent('contextmenu',{bubbles:true,cancelable:true,clientX:g.x,clientY:g.y}));
   return;
  }
  const now=Date.now(),same=lastTap&&lastTap.key===key(g.el)&&now-lastTap.time<400;
  lastTap=same?null:{key:key(g.el),time:now};
  if(g.note){
   if(notePitch(g.li,g.i,g.si)===null&&allowed(g.li,g.i,g.old))mutate(()=>setNotePitch(g.li,g.i,g.si,g.old));
   refreshScore();
   if(same&&g.context)openNoteOptions(g.li,g.i,g.si);
   else if(notePitch(g.li,g.i,g.si)!==null)audition(notePitch(g.li,g.i,g.si));
  }else if(same){g.el.onclick?.call(g.el,new MouseEvent('click',{bubbles:true,cancelable:true}));}
 },true);
 window.addEventListener('pointercancel',e=>{if(!cancellingGesture)fingers.delete(e.pointerId);if(gesture&&e.pointerId===gesture.id){cancel();lastTap=null;suppressUntil=Date.now()+700;}},true);
 window.addEventListener('blur',()=>{fingers.clear();cancel();lastTap=null;});
 document.addEventListener('click',e=>{
  const touchClick=e.pointerType==='touch'||!e.pointerType&&e.detail!==0;
  if(touchClick&&Date.now()<suppressUntil&&e.target.closest(selector)){e.preventDefault();e.stopImmediatePropagation();}
 },true);
 document.addEventListener('selectstart',e=>{
  if(heldRhythmPoint||e.target.closest?.('.sentence-tape,svg.unified-score.click-input'))e.preventDefault();
 });
 document.addEventListener('contextmenu',e=>{
  // Suppress only the touch gesture's native menu, not future mouse/keyboard use.
  const touchMenu=!!gesture||e.pointerType==='touch'||e.pointerType!=='mouse'&&Date.now()<suppressUntil;
  if(touchMenu&&e.target.closest(selector)){e.preventDefault();e.stopImmediatePropagation();}
 },true);
 const oldRender=render;render=function(){oldRender();const area=$('#scoreArea');if(!(project().level<=10&&inSentence())&&area?.querySelector('.note')&&!document.querySelector('[data-operation-demo="pitch"]')){const hint=document.createElement('button');hint.type='button';hint.id='touchHelp';hint.className='touch-help operation-demo-link';hint.dataset.operationDemo='pitch';hint.textContent='▶ 看音高演示';area.before(hint);}};
}
