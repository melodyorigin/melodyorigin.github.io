/* Chapters 3–4 extend the existing journey without changing its first two lessons. */
const CHAPTER_KEYS=['','one','two','three','four'];
const CHAPTER_TITLES=['','春晓 · 初次创作','春晓 · 旋律的重复','小花猫','小雨点'];
function currentChapter(){for(let n=1;n<=4;n++)if(!db[CHAPTER_KEYS[n]]?.complete)return n;return 4;}
function startChapter(n){if(n===1)return start('one');if(n===2)return beginTwo();const key=CHAPTER_KEYS[n];if(!db[key]){const texts=n===3?['小花猫伸伸腰','追着尾巴转圈跑','转呀转呀没追到','躺回窝里睡大觉']:['小雨点敲小窗','滴滴答答脆又响','叶子摇头小草忙','喝饱雨水往上长'];const p=fresh(n,texts);p.title=CHAPTER_TITLES[n];p.lyricist='Chat gpt';p.meter='4/4';p.maxStep=0;p.barsPerRow=0;p.uiVersion=2;p.lines.forEach((l,li)=>{const lens=li===0?[2,1,2,1]:[2,2,2,1];let at=0;const ends=lens.slice(0,-1).map(v=>(at+=v));l.cuts=lyricUnits(l.text).slice(0,-1).map((_,i)=>ends.includes(i+1));l.punct=li%2===0?'，':'。';l.staccato=Array(lyricUnits(l.text).length).fill(false);});db[key]=p;}start(key);}
function laterMeter(){const p=project(),ms=['4/4'];$('#stage').innerHTML=heading('选择节拍',p.level===3?'这次我们就选4/4拍啦':'选个你想要的节拍','')+`<div class="choices">${ms.map(m=>`<button data-lesson-meter="${m}" class="${p.meterChosen&&p.meter===m?'primary':''}">${m} 拍</button>`).join('')}</div>`;$$('[data-lesson-meter]').forEach(b=>b.onclick=()=>{mutate(()=>{p.meter=b.dataset.lessonMeter;p.meterChosen=true;if(boundedLesson(p))p.lines.forEach(l=>normalizeLessonLine(l,p));});render();});nav(true,'选择速度');$('#next').disabled=!p.meterChosen;}
function laterRhythms(n,p=project()){
  if(n<1||n>4)return [];const limit=8,out=[];
  function add(prefix,left){if(prefix.length===n){if(prefix.reduce((sum,v)=>sum+v,0)%2===0)out.push(prefix.map(v=>v/2));return;}const remain=n-prefix.length-1;for(let v=1;v<=Math.min(8,left-remain);v++){if(v===5||v===7)continue;add([...prefix,v],left-v);}}
  add([],limit);return out.sort((a,b)=>a.reduce((s,v)=>s+v,0)-b.reduce((s,v)=>s+v,0));
}
function rhythmWindow(all,current,key){return all;}
function rhythmBrowseHTML(){return '';}
function bindRhythmBrowse(refresh){}

function staccatoDone(p=project()){return [0,1,2,3].every(i=>p.lines[1].staccato?.[i]);}
function renderStaccato(){const p=project();$('#stage').innerHTML=heading('加入跳音','让「滴滴答答」跳起来','')+editingControls()+`<div id="scoreArea">${scoreHTML()}</div>`;bindPlayback();nav(true,'完成作品',()=>{const error=validate(p);if(error){toast(error);return;}if(!staccatoDone()){toast('给「滴滴答答」四个音符都加上跳音点');return;}mutate(()=>{p.step=7;p.complete=true;});stop();render();});$('#next').disabled=!staccatoDone();}
function bindArticulation(){const p=project();if(p.level!==0&&(curriculum(p)?p.level<4:p.level!==4))return;$$('.note').forEach(el=>{el.oncontextmenu=e=>{e.preventDefault();const li=+el.dataset.li,i=+el.dataset.i,si=+(el.dataset.si||0),l=p.lines[li];const existing=l.melody?.[i]?.[si]??null,on=existing?existing.staccato:l.staccato?.[i];const m=$('#modal');m.innerHTML=`<h2>「${esc(lyricUnits(l.text)[i])}」</h2><button id="toggleStaccato" class="primary">${on?'移除跳音':'添加跳音'}</button><div class="actions"><button id="cancelArticulation">返回乐谱</button></div>`;$('#toggleStaccato').onclick=()=>{mutate(()=>{if(existing)existing.staccato=!on;else{l.staccato??=Array(lyricUnits(l.text).length).fill(false);l.staccato[i]=!on;}});m.close();refreshScore();if(p.level===4&&p.step===(sentenceLesson(p)?3+p.lines.length:6)&&$('#next'))$('#next').disabled=!staccatoDone();if(notePitch(li,i,si)!==null)playEvents([{t:0,d:l.durations[i]??1,p:notePitch(li,i,si),staccato:!on}]);};$('#cancelArticulation').onclick=()=>m.close();m.showModal();};});}
