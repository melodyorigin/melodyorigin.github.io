/* Per-bar engraving layout. These controls never change musical time. */
function scoreLayoutCurrentBars(p=project()){
 const portrait=typeof window!=='undefined'&&typeof window.matchMedia==='function'&&window.matchMedia('(orientation: portrait)').matches;
 return scoreLayoutBarsForDevice(p,portrait);
}
function scoreLayoutLesson(p=project()){
 if(!p||p.level<28||p.level>30||p.advancedReview!==undefined||p.knowledgeLesson!==undefined)return 0;
 const step=advancedStep(p);
 return step?.kind==='review'||step?.kind==='section-compose'&&sectionComposeState(p).phase==='compose'?p.level:0;
}
function scoreLayoutEnabled(){
 if(db.view!=='editor')return false;
 return !['knowledge-names','knowledge-transposed'].includes(advancedLesson()?advancedStep()?.kind:'');
}
function scoreLayoutRenderedRow(svg){
 const data=svg.dataset.layoutRow?JSON.parse(svg.dataset.layoutRow):null;
 const scope=data?.layoutScope,focus=scope?.startsWith('phrases:')?scope.slice(8).split(',').map(Number):null;
 return systemModel(project(),focus).find(row=>data?row.measures[0].layoutKey===data.measures[0].layoutKey:row.measures[0].number===+svg.dataset.firstMeasure);
}
function openScoreLayout(row,key){
 const index=row.measures.findIndex(m=>m.layoutKey===key);if(index<0)return;
 const measure=row.measures[index],end=index===row.measures.length-1;
 const canBreak=!end,canJoin=end&&!!row.layoutNextMeasure,modal=$('#modal');
 modal.innerHTML=`<div class="eyebrow">乐谱换行</div><h2>第 ${measure.number+1} 小节后</h2><div class="score-layout-actions"><button id="forceScoreBreak" ${canBreak?'':'disabled'}>强制折行<small>让这一行在此结束</small></button><button id="cancelScoreBreak" ${canJoin?'':'disabled'}>强制取消折行<small>从下一行移上来一个小节</small></button></div><div class="actions"><button id="closeScoreLayout">返回乐谱</button></div>`;
 const apply=layout=>{if(!layout)return;stop();mutate(()=>{const p=project();p.barsPerRow=scoreLayoutCurrentBars(p);p.layoutVersion=4;p.scoreLayoutExplicit=true;p.scoreLayout=layout;});modal.close();render();};
 $('#forceScoreBreak').onclick=()=>{if(canBreak)apply(scoreLayoutForceBreak(row,key,project()));};
 $('#cancelScoreBreak').onclick=()=>{if(canJoin)apply(scoreLayoutCancelBreak(row,row.layoutNextMeasure,project()));};
 $('#closeScoreLayout').onclick=()=>modal.close();if(!modal.open)modal.showModal();
}
function scoreLayoutHintHTML(lesson){
 if(lesson===28)return '<p>右键小节线，可以选择强制折行。</p><p class="hint">比如原来是 4 小节一行，想让这一行变成 3 小节，就右键第 3 小节后的小节线，选择“强制折行”。</p>';
 if(lesson===29)return '<p>右键每行最后的小节线，可以选择强制取消折行。</p><p class="hint">每取消一次，就从下一行移上来一个小节。可以一小节一小节地调整谱面。</p>';
 return '';
}
function bindScoreLayout(){
 if(!scoreLayoutEnabled())return;
 const area=$('#scoreArea');if(!area)return;
 const lesson=scoreLayoutLesson(),ns='http://www.w3.org/2000/svg';
 for(const svg of area.querySelectorAll('svg[data-layout-row]')){
  const row=JSON.parse(svg.dataset.layoutRow);
  svg.querySelector('.score-layout-overlay')?.remove();
  const overlay=document.createElementNS(ns,'g');overlay.classList.add('score-layout-overlay');
  row.measures.forEach((measure,i)=>{
   const x=measure.x+measure.width-5,end=i===row.measures.length-1;
   let hit=svg.querySelector(`[data-drag-bar="${measure.number}"]`);
   if(!hit){
    hit=document.createElementNS(ns,'g');hit.setAttribute('class','bar-drag-handle score-layout-handle');
    hit.innerHTML=`<rect x="${x-10}" y="136" width="20" height="76" fill="transparent" pointer-events="all"/>`;
    hit.onpointerdown=e=>{e.stopPropagation();};overlay.append(hit);
   }
   hit.dataset.layoutBar=measure.layoutKey;hit.setAttribute('tabindex','0');hit.setAttribute('role','button');
   const draggable=hit.hasAttribute('data-drag-bar');
   hit.setAttribute('aria-label',`${draggable?'拖动或':''}右键第 ${measure.number+1} 小节线：乐谱换行`);
   hit.oncontextmenu=e=>{e.preventDefault();e.stopPropagation();openScoreLayout(row,measure.layoutKey);};
   hit.onkeydown=e=>{if(e.key==='ContextMenu'||e.shiftKey&&e.key==='F10'||e.key==='Enter'){e.preventDefault();e.stopPropagation();openScoreLayout(row,measure.layoutKey);}};
   const target=lesson===28||lesson===29&&end&&row.layoutNextMeasure;
   if(target){
    const guide=document.createElementNS(ns,'g');guide.setAttribute('class','score-layout-target');guide.setAttribute('pointer-events','none');
    guide.innerHTML=`<rect x="${x-8}" y="144" width="16" height="61" rx="5" fill="none" stroke="currentColor" stroke-width="1.2"/><path d="M${x} 128v12m-3-4l3 4 3-4" fill="none" stroke="currentColor" stroke-width="1.2"/>`;
    overlay.append(guide);
   }
  });
  svg.append(overlay);
 }
 if(lesson&&area.querySelector('svg[data-layout-row]')){
  const heading=$('#stage .section-head');
  if(heading&&!$('#stage .score-layout-intro')){
   const intro=document.createElement('p');intro.className='score-layout-intro';
   intro.textContent='你已经将基础操作学差不多啦～为了传阅你作品时的美观性，我们来将乐谱进行排版，让谱子看着更舒适～';heading.after(intro);
  }
  if(lesson!==30&&!$('#stage .score-layout-bar-hint')){
   const hint=document.createElement('div');hint.className='score-layout-bar-hint';hint.innerHTML=scoreLayoutHintHTML(lesson);area.before(hint);
  }
 }
}
function installScoreLayout(){
 window.matchMedia('(orientation: portrait)').addEventListener('change', () => {
  if (db.view === 'editor' && !project()?.scoreLayoutExplicit) render();
 });
 const oldSVG=engravingSVG,oldControl=layoutControl,oldBind=bindScore,oldRender=render,oldValid=validProject,oldClear=clearWorkMusic,oldSystem=systemModel;
 systemModel=function(p,focusLi=null){
  const value=scoreLayoutCurrentBars(p);
  // Adapt a rendering copy, leaving synced projects and their desktop default intact.
  return oldSystem(value===(p.barsPerRow||0)?p:{...p,barsPerRow:value},focusLi);
 };
 engravingSVG=function(row,mode='combined',editable=true){
  const svg=oldSVG(row,mode,editable);
  const data={measures:row.measures.map(m=>({layoutKey:m.layoutKey,number:m.number,x:m.x,width:m.width})),layoutScope:row.layoutScope,layoutNextMeasure:row.layoutNextMeasure};
  return svg.replace('<svg ',`<svg data-layout-row="${esc(JSON.stringify(data))}" `);
 };
 layoutControl=function(){
  let html=oldControl();
  const effective = scoreLayoutCurrentBars();
  if(effective !== (project().barsPerRow || 0)){
   const label = effective === 'two-phrases' ? '两句一行' : '一句一行';
   html=html.replace(/<summary>[^<]*<\/summary>/,`<summary>乐谱换行 · ${label} ▾</summary>`)
    .replace(/data-layout-bars="([^"]+)" aria-pressed="[^"]*" class="[^"]*"/g,(_,value)=>`data-layout-bars="${value}" aria-pressed="${value===String(effective)}" class="${value===String(effective)?'active':''}"`);
  }
  if(Object.keys(project().scoreLayout?.breaks||{}).length)html=html.replace('<div class="layout-options">','<button type="button" data-reset-score-layout>恢复自动排版</button><div class="layout-options">');
  if(scoreLayoutLesson()===28)html='<div class="score-layout-choice-guide"><span>可以选择几小节一行来折行。</span>'+html+'</div>';
  return html;
 };
 bindScore=function(){
  oldBind();
  $$('[data-layout-bars]').forEach(button=>button.onclick=()=>{
   mutate(()=>{const p=project();p.barsPerRow=['auto-phrases','two-phrases'].includes(button.dataset.layoutBars)?button.dataset.layoutBars:+button.dataset.layoutBars;p.layoutVersion=4;p.scoreLayoutExplicit=true;delete p.scoreLayout;});render();
  });
  $$('[data-reset-score-layout]').forEach(button=>button.onclick=()=>{mutate(()=>delete project().scoreLayout);render();});
  bindScoreLayout();
 };
 render=function(){oldRender();bindScoreLayout();};
 validProject=function(p){return validScoreLayout(p?.scoreLayout)&&oldValid(p);};
 clearWorkMusic=function(p){oldClear(p);delete p.scoreLayout;};
}
