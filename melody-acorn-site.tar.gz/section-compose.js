/* From chapter 21, paragraph grouping and composition share one main step. */
let sectionComposeLegacySteps=null;
function sectionComposeLesson(p=project()){return !!p&&p.level>=21&&advancedLesson(p);}
// Match the duration already used by the staff and playback. Entering a pitch
// accepts that displayed duration even when no rhythm option was clicked first.
function sectionComposeNoteDuration(line,i,p=project()){
 if(line.durations[i]!==null)return line.durations[i];
 const parts=line.melody?.[i];
 return parts?.length?parts.reduce((sum,n)=>sum+n.d,0):(getRhythmPreference(p)==='regular'?regularDefaults(line,p)[i]:boundedLesson(p)?.5:1);
}
function repairSectionComposeTiming(p){
 if(!sectionComposeLesson(p))return false;
 let changed=false;
 for(const line of p.lines)line.durations.forEach((d,i)=>{
  if(d!==null||!Number.isInteger(line.pitches[i])&&!line.melody?.[i]?.length)return;
  const duration=sectionComposeNoteDuration(line,i,p);
  if(!Number.isFinite(duration)||duration<.25||duration>256||Math.abs(duration*12-Math.round(duration*12))>1e-8)return;
  line.durations[i]=duration;changed=true;
 });
 return changed;
}
function sectionComposeState(p=project()){
 const ranges=sectionRanges(p),last=Math.max(0,ranges.length*2-1);
 const clamp=value=>Math.max(0,Math.min(last,Number.isInteger(value)?value:0));
 const stage=clamp(p.sectionComposeStage),maxStage=Math.max(stage,clamp(p.sectionComposeMaxStage));
 const section=Math.floor(stage/2);
 return {section,phase:stage%2?'compose':'groups',stage,maxStage,lines:ranges[section]||[],ranges};
}
// sentenceError uses project() throughout its installed wrappers. A temporary
// store shell lets validation inspect an explicit project without editing the
// actual store, its active composition, or the project being inspected.
function withSectionComposeProject(p,fn){
 if(p===project())return fn();
 const previous=db;db={...db,[db.active]:p};
 try{return fn();}finally{db=previous;}
}
function sectionComposeIssue(stage,p=project()){
 if(!sectionComposeLesson(p))return '';
 const ranges=sectionRanges(p);
 if(!Number.isInteger(stage)||stage<0||stage>=ranges.length*2)return '这个段落步骤不存在';
 const lines=ranges[Math.floor(stage/2)];
 if(stage%2===0){
  const li=lines.find(li=>groups(p.lines[li]).some(group=>group.end-group.start>2));
  return li===undefined?'':`第 ${li+1} 句：先把这句分成每组 1～2 个字`;
 }
 return withSectionComposeProject(p,()=>{
  for(const li of lines){const issue=sentenceError(li);if(issue)return `第 ${li+1} 句：${issue}`;}
  return '';
 });
}
function moveSectionCompose(targetStage){
 const p=project();if(!sectionComposeLesson(p)||advancedStep(p)?.kind!=='section-compose')return false;
 const state=sectionComposeState(p),last=state.ranges.length*2-1;
 if(!Number.isInteger(targetStage)||targetStage<0||targetStage>last)return false;
 if(targetStage>state.maxStage){
  if(targetStage!==state.stage+1||state.stage!==state.maxStage)return false;
  const issue=sectionComposeIssue(state.stage,p);if(issue){toast(issue);return false;}
 }
 if(targetStage===state.stage)return true;
 stop();selected=null;mutate(()=>{p.sectionComposeVersion=1;p.sectionComposeStage=targetStage;p.sectionComposeMaxStage=Math.max(state.maxStage,targetStage);});render();return true;
}
function finishSectionCompose(){
 const p=project();if(!sectionComposeLesson(p)||advancedStep(p)?.kind!=='section-compose')return false;
 const state=sectionComposeState(p);if(state.phase!=='compose'||state.stage!==state.ranges.length*2-1)return false;
 for(let section=0;section<state.ranges.length;section++){
  const issue=sectionComposeIssue(section*2+1,p);if(issue){toast(issue);return false;}
 }
 advanceAdvanced();return true;
}
function sectionComposeHasMusic(p,lines){
 return lines.some(li=>{const l=p.lines[li];return l.durations.some(d=>d!==null)||l.pitches.some(pitch=>pitch!==null)||Object.values(l.melody||{}).some(parts=>parts?.length);});
}
function sectionComposeLegacyStage(p,step,lastLine=false){
 const ranges=sectionRanges(p),last=Math.max(0,ranges.length*2-1);
 if(!step||['meter-tempo','mode','sections'].includes(step.kind))return 0;
 if(step.kind!=='pair')return last;
 const li=lastLine?step.lines.at(-1):step.lines[0],section=Math.max(0,ranges.findIndex(lines=>lines.includes(li)));
 return section*2+(sectionComposeHasMusic(p,ranges[section]||[])?1:0);
}
function migrateSectionComposeProject(p){
 if(!p||!sectionComposeLesson(p)||p.sectionComposeVersion!==undefined||!sectionComposeLegacySteps)return false;
 const steps=sectionComposeLegacySteps(p),step=p.step??0,maxStep=p.maxStep??step;
 // Invalid imported progress must not become valid by clamping it into a page.
 if(!Number.isInteger(step)||step<0||step>=steps.length||!Number.isInteger(maxStep)||maxStep<0||maxStep>=steps.length)return false;
 const map=entry=>entry.kind==='pair'?3:['review','rests','pickup'].includes(entry.kind)?4:entry.kind==='credits'?5:entry.kind==='save'?6:steps.indexOf(entry);
 const stage=sectionComposeLegacyStage(p,steps[step]),maxStage=Math.max(stage,sectionComposeLegacyStage(p,steps[maxStep],true));
 p.step=map(steps[step]);p.maxStep=Math.max(p.step,map(steps[maxStep]));
 p.sectionComposeVersion=1;p.sectionComposeStage=stage;p.sectionComposeMaxStage=maxStage;return true;
}
function migrateRestLessonLayout(p){
 if(p?.level!==22||p.restLessonLayoutVersion===1)return;
 p.restLessonLayoutBackup={lines:clone(p.lines),step:p.step,maxStep:p.maxStep,sectionComposeStage:p.sectionComposeStage,sectionComposeMaxStage:p.sectionComposeMaxStage};
 const at=p.lines.findIndex((l,i)=>l.text==='争渡'&&p.lines[i+1]?.text==='争渡');
 if(at>=0){
  const a=p.lines[at],b=p.lines[at+1],offset=lyricUnits(a.text).length,melody={...a.melody};
  for(const [i,parts] of Object.entries(b.melody||{}))melody[+i+offset]=clone(parts);
  const merged={...a,text:a.text+b.text,punct:b.punct,cuts:[...a.cuts,true,...b.cuts],durations:[...a.durations,...b.durations],pitches:[...a.pitches,...b.pitches],staccato:[...(a.staccato||a.pitches.map(()=>false)),...(b.staccato||b.pitches.map(()=>false))],melody,copyRepairs:[...(a.copyRepairs||[]),...(b.copyRepairs||[]).map(i=>i+offset)]};
  for(const key of ['restsAfter','accidentals'])if(a[key]||b[key]){
   merged[key]={...a[key]};for(const [i,value] of Object.entries(b[key]||{}))merged[key][+i+offset]=value;
  }
  p.lines.splice(at,2,merged);
 }
 p.lines.forEach(l=>l.section=0);
 const oldMax=p.maxStep??p.step;
 p.step=p.step>=3?p.step-1:p.step===2?2:p.step;
 p.maxStep=Math.max(p.step,oldMax>=3?oldMax-1:oldMax);
 p.sectionComposeStage=p.sectionComposeStage%2||p.step>2?1:0;
 p.sectionComposeMaxStage=Math.max(p.sectionComposeStage,p.sectionComposeMaxStage>0?1:0);
 p.sentenceStages=p.lines.map(()=>2);p.sentenceCompleted=p.lines.map(()=>false);
 p.restLessonLayoutVersion=1;
}
function migrateSectionComposeStore(store){
 if(!store||typeof store!=='object')return;
 for(const key of CHAPTER_KEYS){const p=store[key];if(!p||!sectionComposeLesson(p))continue;migrateLaterMeterTempo(p);migrateSectionComposeProject(p);migrateRestLessonLayout(p);repairSectionComposeTiming(p);}
}
function installSectionCompose(){
 const oldSteps=advancedSteps,oldMigrate=migrateV2,oldValid=validProject,oldRender=renderOrderedLesson,oldScore=advancedScoreHTML,oldRefresh=refreshScore,oldBind=bindScore,oldCover=lessonCoverProject,oldEdit=applyEditedLessonLyrics,oldReminder=cadenceStepReminder;
 const oldPitch=setNotePitch,oldSplit=applySplit;
 sectionComposeLegacySteps=oldSteps;
 setNotePitch=function(li,i,si,pitch){
  const p=project(),line=p.lines[li];
  if(sectionComposeLesson(p)&&Number.isInteger(pitch)&&line.durations[i]===null&&!line.melody?.[i]?.[si]?.rest)line.durations[i]=sectionComposeNoteDuration(line,i,p);
  return oldPitch(li,i,si,pitch);
 };
 applySplit=function(li,i,ds){
  const p=project(),line=p.lines[li];
  if(sectionComposeLesson(p)&&line.durations[i]===null)line.durations[i]=ds.reduce((sum,d)=>sum+d,0);
  return oldSplit(li,i,ds);
 };
 advancedSteps=function(p){
  if(!sectionComposeLesson(p))return oldSteps(p);
  return [{kind:'meter-tempo',name:'节拍和速度'},{kind:'mode',name:'选择调式'},...(p.level===22?[]:[{kind:'sections',name:'编辑歌词与分段'}]),{kind:'section-compose',name:'旋律创作'},p.level===23?{kind:'pickup',name:'弱起小节'}:p.level===22?{kind:'rests',name:'加入休止'}:{kind:'review',name:'自由修改'},{kind:'credits',name:'完成作品'},{kind:'save',name:'保存作品'}];
 };
 migrateV2=function(){
  // Both migrations precede oldMigrate's maxStep clamp to the shorter list.
  migrateLessonOrder();
  for(const store of [db,db.journeyBackup,db.rhythmBackups])migrateSectionComposeStore(store);
  oldMigrate();
 };
 validProject=function(p){
  try{
  const normalized=normalizeLessonOrderProject(p);
  if(!sectionComposeLesson(normalized))return oldValid(p);
  if(!Array.isArray(normalized.lines)||normalized.lines.length===0||normalized.lines.some(l=>!l||typeof l.text!=='string'))return false;
  if(normalized.sectionComposeVersion!==undefined&&normalized.sectionComposeVersion!==1)return false;
  const legacy=normalized.sectionComposeVersion!==1,meterOffset=normalized.meterTempoVersion===1?0:1;
  // The meter/tempo migration is independent of the paragraph-flow marker:
  // older setup indexes still carry one extra page before this flow's steps.
  const restLayoutOffset=normalized.level===22&&normalized.restLessonLayoutVersion!==1?1:0;
  const limit=(legacy?oldSteps(normalized).length-1:advancedSteps(normalized).length-1+restLayoutOffset)+meterOffset;
  if(!Number.isInteger(normalized.step)||normalized.step<0||normalized.step>limit)return false;
  if(normalized.maxStep!==undefined&&(!Number.isInteger(normalized.maxStep)||normalized.maxStep<0||normalized.maxStep>limit))return false;
  if(!legacy){
   const last=sectionRanges(normalized).length*2-1;
   for(const key of ['sectionComposeStage','sectionComposeMaxStage'])if(normalized[key]!==undefined&&(!Number.isInteger(normalized[key])||normalized[key]<0||normalized[key]>last))return false;
  }
  const candidate=clone(normalized);migrateLaterMeterTempo(candidate);
  if(legacy&&!migrateSectionComposeProject(candidate))return false;
  migrateRestLessonLayout(candidate);repairSectionComposeTiming(candidate);
  return oldValid(candidate);
  }catch(error){return false;}
 };
 lessonCoverProject=function(level){
  const p=oldCover(level);
  // Reading an existing cover is observational; actual legacy projects migrate
  // at startup or on import, not while the user browses adjacent covers.
  if(sectionComposeLesson(p)&&!db[CHAPTER_KEYS[level]]){p.sectionComposeVersion=1;p.sectionComposeStage=0;p.sectionComposeMaxStage=0;migrateRestLessonLayout(p);}
  return p;
 };
 applyEditedLessonLyrics=function(text,p=project()){
  const before=sectionComposeLesson(p)?JSON.stringify(p.lines):null,result=oldEdit(text,p);
  if(!result&&before!==null&&JSON.stringify(p.lines)!==before){p.sectionComposeVersion=1;p.sectionComposeStage=0;p.sectionComposeMaxStage=0;}
  return result;
 };
 renderOrderedLesson=function(){if(repairSectionComposeTiming(project()))save();return sectionComposeLesson()&&advancedStep()?.kind==='section-compose'?renderSectionCompose():oldRender();};
 advancedScoreHTML=function(){return sectionComposeLesson()&&advancedStep()?.kind==='section-compose'?sectionComposeScoreHTML():oldScore();};
 refreshScore=function(){oldRefresh();syncSectionComposeGate();};
 bindScore=function(){oldBind();syncSectionComposeGate();};
 cadenceStepReminder=function(kind){
  const p=project();if(kind!=='旋律创作'||!sectionComposeLesson(p)||advancedStep(p)?.kind!=='section-compose')return oldReminder(kind);
  const state=sectionComposeState(p);if(state.phase!=='compose')return '';
  return state.lines.map(li=>{const rule=cadenceRequirement(p,li);return rule?`第 ${li+1} 句最后的「${lyricUnits(p.lines[li].text).at(-1)}」${rule.ending?'请回到':'请停在'} ${rule.names} 音，调整乐谱中框出的最后一个音。`:'';}).filter(Boolean).join(' ');
 };
}
