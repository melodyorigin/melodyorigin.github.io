/* A quiet look at the words before any composition controls appear. */
const LESSON_COVER_INVITATIONS={
 1:'就从这两句《春晓》开始吧～把字放长一点、放短一点，再给它们找个音高，试试看。',
 2:'前两句已经会唱了，把熟悉的旋律再用一次，稍微改一改，就能唱完整首《春晓》啦。',
 3:'小花猫今天想怎么走？试着换换字词的分法，看看同一句话会不会唱出另一种样子。',
 4:'雨点落下来，是黏在一起，还是一颗一颗跳出来？给「滴滴答答」加几个小点，听听～',
 5:'这首诗有没有让你想到高山和远方？这次换一组声音，试试唱出一点中国味道～',
 6:'让纸飞机跟着一、二、三轻轻转个圈～选好3/4拍，听它能飞出什么样的旋律。',
 7:'这次就照你的感觉写吧～瀑布可以一下冲下来，也可以先攒一攒力气。',
 8:'月光落下来，家好像又近了一点。这次从A出发，给思念找个声音吧～',
 9:'还是这轮月亮，这次只带上五个音。听听它和上一首有什么不一样～',
 10:'小船都快出发啦，这回节拍、速度、旋律就由你安排。让它轻快地走，也可以慢慢看风景～',
 11:'两首词，挑一首有感觉的吧～把上一句的旋律搬高一点、放低一点，听听上下句怎么回应。',
 12:'一句词还没唱够？让一个字多转几个音，听听这首《浣溪沙》能怎么唱～',
 13:'春天唱过的旋律，秋天也可以接着唱。把一整段搬过去，看看两季的词会遇到什么样的声音～',
 14:'还是这条山路，下一段风景却有点不一样。复制一段旋律，再把对不上的地方慢慢补好吧～',
 15:'这张旧照片里，你想把哪几句放在一起？用空行分好段，再给回忆写一首歌。',
 16:'渡口的风要往哪里走呢？从D出发，每段结尾让四个音一级一级走回D，听听这个味道～',
 17:'今晚没有指定路线啦，跟着词里的路灯和月光走。前面玩过的办法，喜欢哪个就用哪个～',
 18:'海风推一下，小船再摇一下～试试6/8拍，听听旋律能不能也摇起来。',
 19:'给熟悉的五个音添一个 B，听听这首送别词会有什么变化～B 叫变宫，少放在正拍上试试。',
 20:'远处那盏灯，会让你想起谁？把词改成自己的故事，写一首想送给对方的歌吧～',
 21:'一封寄向远方，一封写着归期～两段旋律可以彼此呼应，也可以有点不同，试试看。',
 22:'争渡，争渡～两声之间停一下，会不会更有意思？这次给旋律留一点空隙。',
 28:'这次把田园里的自在，写成你自己的旋律吧～',
 29:'一路走过晨光和星光，把这段旅途唱出来吧～',
 30:'已经写到第三十首啦，把远方的故事唱给想念的人听吧～',
 26:'同样从 A 出发，这次 G 会悄悄升高。听听它是不是更想回到 A 了～',
 27:'先让两个 G 在同一小节相遇，再让后一个回到原来的高度，听听这点变化。',
 24:'换成英文唱唱看～一个单词可能要分几口唱，先听听音节，再给它们配旋律。',
 25:'同一个位置的音，也能换一种味道。点开音符试试升、降、还原，听听哪里最合你心意。',
 23:'这次不一定要等到第一拍才出发哦～挪一挪小节线，听听旋律抢先迈出一步的感觉。'
};
function lessonCoverWorks(p=project()){
 if(p.level===11&&p.lyricChoice===undefined)return LYRIC_CHOICES.map(c=>({title:c.title,author:'Chat gpt',lines:c.lines.map(text=>({text,section:0}))}));
 const fallback=p.level<=2?'孟浩然':ADVANCED_LESSONS[p.level]?.author||NEW_LESSONS[p.level]?.author||'Chat gpt';
 // The second chapter starts with a copy of the half-poem; show all four lines
 // here without inserting or arranging the remaining two in the saved project.
 const lines=p.level===2&&p.lines.length<4?POEM.map((text,i)=>({text,punct:i%2?'。':'，',section:0})):p.lines;
 return [{title:p.title,author:p.lyricist||fallback,lines}];
}
function lessonCoverLyrics(lines,showSections=false){
 // Chapter 21 explicitly previews its two sections, including later user edits.
 // Other covers retain the continuous lyric presentation.
 const paragraphs=[];lines.forEach((l,i)=>{if(!i||showSections&&(l.section??0)!==(lines[i-1].section??0))paragraphs.push([]);paragraphs.at(-1).push(l);});
 return paragraphs.map(part=>`<p>${part.map(l=>`<span>${esc(l.text==='争渡争渡'?'争渡 争渡':l.text)}${esc(l.punct||'')}</span>`).join('')}</p>`).join('');
}
function lessonHasStarted(p=project()){return p.step>0||p.maxStep>0||p.complete||p.lines.some(l=>l.durations.some(d=>d!==null)||l.pitches.some(v=>v!==null));}
function lessonCoverProject(level){
 const saved=db[CHAPTER_KEYS[level]];if(saved){applyNineteenMode(saved);return saved;}
 const early={1:{title:'春晓',author:'孟浩然',lines:POEM.slice(0,2)},2:{title:'春晓',author:'孟浩然',lines:POEM},3:{title:'小花猫',author:'Chat gpt',lines:['小花猫伸伸腰','追着尾巴转圈跑','转呀转呀没追到','躺回窝里睡大觉']},4:{title:'小雨点',author:'Chat gpt',lines:['小雨点敲小窗','滴滴答答脆又响','叶子摇头小草忙','喝饱雨水往上长']}};
 const c=early[level]||ADVANCED_LESSONS[level]||NEW_LESSONS[level],p=fresh(level,c.lines);
 p.title=c.title;p.lyricist=c.author;if(level>=16)p.meterTempoVersion=1;if(level>=19)p.lessonOrderVersion=3;p.lines.forEach((l,i)=>{if(level>=3)l.cuts=l.cuts.map((_,j)=>(j+1)%2===0);l.section=level>=15&&!c.defaultSections?0:c.sections?.[i]??0;l.punct=c.punctuation?.[i]??(i%2?'。':'，');});applyNineteenMode(p);return p;
}
function validCoverLevel(n){return Number.isInteger(n)&&n>0&&n<CHAPTER_KEYS.length;}
function lessonUnlocked(n){return n===1||!!db[CHAPTER_KEYS[n]]||!!db[CHAPTER_KEYS[n-1]]?.complete;}
function showLessonCover(level=project()?.level){if(!validCoverLevel(level))return;stop();selected=null;db.coverLevel=level;db.view='lesson-cover';save();render();}
let enteringCoverLevel=null;
function beginCoverLesson(level){
 if(!lessonUnlocked(level))return;
 const p=db[CHAPTER_KEYS[level]];
 if(p&&!p.coverSeenLevel&&!lessonHasStarted(p))p.rhythmPreference=getRhythmPreference();
 if(p)p.coverSeenLevel=level;
 delete db.coverLevel;enteringCoverLevel=level;
 try{if(project()?.level===level){db.view='editor';save();render();}else if(p)start(CHAPTER_KEYS[level]);else startChapter(level);}
 finally{enteringCoverLevel=null;}
 if(project()?.level===level){project().coverSeenLevel=level;save();}
}
function renderLessonCover(){
 const level=validCoverLevel(db.coverLevel)?db.coverLevel:project().level,p=lessonCoverProject(level),works=lessonCoverWorks(p),started=lessonHasStarted(p),unlocked=lessonUnlocked(level),label=!unlocked?'完成上一关后开始':started?'继续创作':p.level===11&&p.lyricChoice===undefined?'去选一首':'开始谱曲';
 $('#app').innerHTML=`<div class="toolbar lesson-cover-toolbar"><button id="coverHome">← 首页</button>${level>1?`<button id="coverPrevious">← 上一关：${esc(CHAPTER_TITLES[level-1])}</button>`:''}<button id="coverCurrent" class="eyebrow chapter-title-button" aria-current="page">第 ${level} 关 · ${esc(p.title)}</button>${level<CHAPTER_KEYS.length-1?`<button id="coverNext">下一关：${esc(CHAPTER_TITLES[level+1])} →</button>`:''}</div><section class="lesson-cover">${lessonIllustration(level, 'lesson-cover-art', p.title)}<div class="lesson-cover-works ${works.length>1?'has-choices':''}">${works.map(w=>`<article class="lesson-cover-poem"><h1 class="song-title">${esc(w.title)}</h1><p class="lesson-cover-author">作词：${esc(w.author)}</p><div class="lesson-cover-lyrics">${lessonCoverLyrics(w.lines,p.level===21)}</div></article>`).join('')}</div><p class="lesson-cover-invitation">${esc(LESSON_COVER_INVITATIONS[p.level]||'先读读这些词，给它们找一段你喜欢的旋律吧～')}</p><div class="lesson-cover-actions"><button id="coverBegin" class="primary" ${unlocked?'':'disabled'}>${label} →</button></div></section>`;
 $('#coverHome').onclick=home;
 $('#coverCurrent').onclick=()=>showLessonCover(level);
 if($('#coverPrevious'))$('#coverPrevious').onclick=()=>showLessonCover(level-1);
 if($('#coverNext'))$('#coverNext').onclick=()=>showLessonCover(level+1);
 $('#coverBegin').onclick=()=>beginCoverLesson(level);
}
function installLessonCovers(){
 const oldRender=render,oldEditor=renderEditor;
 render=function(){
  const p=project();
  // New chapters show their words first. An existing in-progress composition
  // stays at its saved step; its cover remains accessible from the toolbar.
  if(db.view==='editor'&&p?.level>0&&p.step===0&&!p.complete&&p.coverSeenLevel!==p.level&&enteringCoverLevel!==p.level){db.coverLevel=p.level;db.view='lesson-cover';save();}
  if(db.view==='lesson-cover'&&(validCoverLevel(db.coverLevel)||p?.level>0)){$('#journey').classList.add('active');$('#studio').classList.remove('active');renderLessonCover();return;}
  oldRender();
 };
 renderEditor=function(){
  oldEditor();const p=project();if(!p?.level)return;
  $('#currentChapter').onclick=()=>showLessonCover(p.level);
  if($('#previousLevel'))$('#previousLevel').onclick=()=>showLessonCover(p.level-1);
  if($('#nextLevel'))$('#nextLevel').onclick=()=>showLessonCover(p.level+1);
  if($('#returnTwo'))$('#returnTwo').onclick=()=>showLessonCover(p.level+1);
 };
}
