/* Journey and focused editing UI. Existing project data is migrated in place. */
function migrateV2(){
  migrateSmallGroups();
  migrateTutorialRhythm();
  [...CHAPTER_KEYS.slice(1),'studio'].forEach(key=>{const p=db[key];if(!p)return;
    if(p.level===2&&!p.uiVersion){if(p.step>=2){p.step=2;p.complete=false;}p.rhythmBaseline=clone(p.lines.at(-1).durations);}
    if(p.level!==2&&(!p.flowVersion||p.flowVersion<3)){if(p.step>=1)p.step++;if(p.maxStep>=1)p.maxStep++;p.meter='4/4';p.flowVersion=3;}
    if(p.level!==2&&p.flowVersion<4){if(p.step>=4)p.step++;if(p.maxStep>=4)p.maxStep++;p.mode='C大调';p.flowVersion=4;}
    if(p.level===2&&p.lines.length===4&&!p.rhythmFirstBaseline)p.rhythmFirstBaseline=clone(p.lines[0].durations);
    p.uiVersion=2;p.maxStep=Math.min(saveStep(p),p.maxStep??p.step);if(p.level===2&&p.lines.length===2)p.maxStep=0;if(p.layoutVersion!==4){if(p.barsPerRow===undefined||p.barsPerRow==='two-phrases'||p.barsPerRow===0&&p.layoutVersion!==3)p.barsPerRow='auto-phrases';p.layoutVersion=4;}
    p.lines.forEach((l,i)=>{l.punct??=p.level?(i%2===0?'，':'。'):'';});studioMigrate(p);if(!p.saveFlow){if(p.creditsConfirmed&&p.step===creditStep(p))p.step=saveStep(p);p.saveFlow=1;p.maxStep=Math.max(p.maxStep,p.step);}
  });
}
function renderEditor(){
  const p=project();p.maxStep=Math.max(p.maxStep??0,p.step);const labels=stepNames(p);
  $('#app').innerHTML=`<div class="toolbar editor-top"><button id="back">← 首页</button>${p.step>0?`<button id="previousStep">← 上一步：${labels[p.step-1]}</button>`:''}${p.level>1?`<button id="previousLevel">← 上一关：${CHAPTER_TITLES[p.level-1]}</button>`:''}${p.level?`<button id="currentChapter" class="eyebrow chapter-title-button">第 ${p.level} 关 · ${esc(p.title)}</button>`:`<span class="eyebrow">自由创作 · ${esc(p.title)}</span>`}${p.level>0&&p.level<CHAPTER_KEYS.length-1?`<button id="nextLevel">下一关：${esc(CHAPTER_TITLES[p.level+1])} →</button>`:''}<span class="right hint">♩=${p.bpm} · ${studioModeLabel(p)}</span><button id="undo" title="撤销 Ctrl/⌘ Z" ${undo.length?'':'disabled'}>↶</button><button id="redo" title="重做" ${redo.length?'':'disabled'}>↷</button><button id="backup">备份工程</button>${db.rhythmBackups?.[db.active]?'<button id="oldRhythm">旧节奏备份</button>':''}</div><div class="steps compact-steps">${labels.map((t,i)=>`<button class="step ${i===p.step?'current':i<p.step?'done':''}" data-step="${i}" ${i>p.maxStep?'disabled':''}><span>${i<p.step?'✓':i+1}</span> ${t}</button>`).join('')}</div><section class="workspace"><div id="stage"></div></section>`;
  $('#back').onclick=home;if($('#previousStep'))$('#previousStep').onclick=goBackStep;if($('#previousLevel'))$('#previousLevel').onclick=()=>startChapter(p.level-1);if($('#nextLevel'))$('#nextLevel').onclick=()=>startChapter(p.level+1);$$('[data-step]').forEach(b=>b.onclick=()=>{const step=+b.dataset.step;if(step>p.maxStep)return;if(!sentenceLesson(p)&&p.step===(mergedStudio(p)?1:p.controlOrder===2?3:0)&&step>p.step&&p.level!==2&&!checkGroups())return;stop();mutate(()=>p.step=step);selected=null;render();});$('#undo').onclick=()=>history(true);$('#redo').onclick=()=>history(false);$('#backup').onclick=backup;if($('#oldRhythm'))$('#oldRhythm').onclick=backupOldRhythm;
  if(sentenceLesson(p))renderOrderedLesson();else if(p.level===0)renderStudioStep();else if(p.level===2)renderTwo();else if(p.step===0)renderGroups();else if(p.step===1)(p.level>=3?laterMeter():renderMeter());else if(p.step===2)renderTempo();else if(p.step===3)renderRhythm();else if(p.step===4)renderMode();else if(p.step===5)renderPitch();else if(p.level===4&&p.step===6)renderStaccato();else renderFinish();
}
function renderRhythm(){
  const p=project();p.lines.forEach(l=>{fillLyricDurations(l,p);l.dragRhythm=true;});
  $('#stage').innerHTML=heading('安排节奏','安排歌词节奏','')+p.lines.map((l,li)=>rhythmLessonTape(li,`data-rhythm-line="${li}"`)).join('');
  $$('[data-rhythm-line]').forEach(b=>b.onclick=()=>playAll(true,+b.dataset.rhythmLine));
  nav(true,'展开五线谱',()=>{if(p.lines.some(l=>l.durations.some(d=>d===null))){toast('还有歌词缺少时长');return;}stop();mutate(()=>p.step++);render();});
}
function editingControls(extraPlayback=''){
  return `<div class="score-controls"><div class="score-playback-tools"><button type="button" class="primary" id="playAll" aria-keyshortcuts="Space" title="播放或暂停（空格键）">▶ 播放</button><button type="button" id="stop" title="停止" aria-label="停止播放">■</button>${extraPlayback}</div>${layoutControl()}<span id="selection" class="hint">音高随时都可以通过拖动、点击、按上下键进行调整</span></div>`;
}
function bindPlayback(){if($('#playAll'))$('#playAll').onclick=togglePlay;if($('#stop'))$('#stop').onclick=stop;bindScore();}
function renderPitch(){
  const p=project();$('#stage').innerHTML=heading('写出旋律','现在可以调整每个字对应的音高啦～','')+editingControls()+`<div id="scoreArea">${scoreHTML()}</div>`;
  bindPlayback();
  nav(true,'完成作品',()=>{const error=validate(p);if(error){toast(error);return;}stop();mutate(()=>{p.step=6;p.complete=p.level!==4;});render();});
}
function beginTwo(){

  if(!db.two){db.two=clone(db.one);db.two.level=2;db.two.step=0;db.two.maxStep=0;db.two.complete=false;db.two.uiVersion=2;db.two.showWholeScore=false;db.two.sentenceStages=[0,0,0,0];db.two.sentenceCompleted=[false,false,false,false];db.two.creditsConfirmed=false;}
  start('two');
}
function pitchTaskDone(){const p=project();return p.lines.length===4&&[1,4,6].includes(p.lines[1].pitches[4]%7);}
function rhythmTaskDone(){const p=project();return !!p.rhythmFirstBaseline&&p.lines.length===4&&JSON.stringify(p.lines[0].durations.slice(0,2))!==JSON.stringify(p.rhythmFirstBaseline.slice(0,2));}
function updateTaskStatus(){
  const p=project();if(p.level!==2||![1,2].includes(p.step))return;
  const done=p.step===1?pitchTaskDone():rhythmTaskDone(),b=$('#taskNext'),status=$('#taskStatus');
  if(b)b.disabled=!done;if(status){status.textContent=done?'✓ 已完成这次变化':'待完成';status.classList.toggle('done',done);}
}
function renderTwo(){
  const p=project();
  if(p.step===0){
    $('#stage').innerHTML=`<div class="chapter-intro"><h2>旋律的重复</h2><div class="poem-transfer"><span>春眠不觉晓，处处闻啼鸟。</span><span>↓ 复制旋律</span><strong>夜来风雨声，花落知多少。</strong></div><div class="actions"><button id="hearOld">▶ 听我的旋律</button><button class="primary" id="copyMelody">下一步：中间的休息 →</button></div></div><div class="work-preview"><h3>已经完成的作品</h3><div id="scoreArea" data-readonly="true">${scoreHTML(false)}</div></div>`;
    $('#hearOld').onclick=()=>playAll();$('#copyMelody').onclick=()=>{mutate(()=>{if(p.lines.length===2)p.lines.push(...p.lines.map((l,i)=>({...clone(l),text:POEM[i+2],punct:i===0?'，':'。'})));p.rhythmBaseline=clone(p.lines[3].durations);p.rhythmFirstBaseline=clone(p.lines[0].durations);p.step=1;});stop();render();};bindScore();return;
  }
  if(p.step>=3){renderFinish();return;}
  const rhythm=p.step===2;
  $('#stage').innerHTML=heading(stepNames(p)[p.step],rhythm?'试着修改一组歌词的节奏':'试着调整中间休息的位置','')+editingControls()+`<div id="scoreArea">${scoreHTML()}</div><div class="actions"><button id="taskBack">← 上一步：${stepNames(p)[p.step-1]}</button><span id="taskStatus" class="task-status">待完成</span><button id="taskNext" class="primary">下一步：${rhythm?'完成作品':'节奏更改'} →</button></div>`;
  bindPlayback();
  $('#taskBack').onclick=()=>{stop();mutate(()=>p.step--);render();};
  $('#taskNext').onclick=()=>{if(rhythm){const error=validate(p);if(error){toast(error);return;}if(!rhythmTaskDone())return;mutate(()=>{p.step=3;p.complete=true;p.showWholeScore=true;});}else{if(!pitchTaskDone())return;mutate(()=>{p.step=2;p.rhythmBaseline=clone(p.lines[3].durations);p.rhythmFirstBaseline=clone(p.lines[0].durations);p.showWholeScore=false;});}stop();selected=null;render();};updateTaskStatus();
}
function renderFinish(){
  const p=project();if(p.step<=creditStep(p)||!p.creditsConfirmed){renderCredits();return;}$('#stage').innerHTML=`<div class="finish compact-finish"><div><span class="eyebrow">保存作品</span><h2>${p.level===30?'恭喜毕业你已经不是乐理小白啦～':p.level===1?'哇～快听听你的第一次创作～':'恭喜你创作了一整首作品，可以把它进行保存哦'}</h2>${p.level===30?'<p class="graduation-message">相信你已经掌握了基础操作，可以自己创作歌曲了。试试用自己的歌词写一首歌吧～加油哦</p>':''}</div><button id="finishPlay" class="primary">▶ 整首播放</button></div><div class="completion-tools">${layoutControl()}<button id="editAgain">← 上一步：完成作品</button>${p.level>0&&p.level<Math.max(15,CHAPTER_KEYS.length-1)?`<button id="returnTwo" class="primary">下一关：${CHAPTER_TITLES[p.level+1]} →</button>`:''}</div><div id="scoreArea" data-readonly="true" data-complete="true">${completedScoreHTML()}</div><div class="export-grid compact-export" ${p.level===1?'hidden':''}><button data-export="staff">五线谱 PDF<small>带歌词 · 打印收藏</small></button><button data-export="jianpu">简谱 PDF<small>带歌词 · 跟着唱</small></button><button data-export="mp3">MP3 音频<small>分享给朋友</small></button><button data-export="midi">MIDI 文件<small>继续编曲</small></button><button data-export="musicxml">MusicXML 乐谱<small>到其他制谱软件继续编辑</small></button></div>`;
  $('#finishPlay').onclick=togglePlay;updatePlay();if($('#returnTwo'))$('#returnTwo').onclick=()=>startChapter(p.level+1);$('#editAgain').onclick=()=>{mutate(()=>{p.step=creditStep(p);p.creditsConfirmed=false;});stop();render();};bindScore();
  $$('[data-export]').forEach(b=>b.onclick=async()=>{try{if(b.dataset.export==='musicxml')exportMusicXML();else if(b.dataset.export==='midi')exportMidi();else if(b.dataset.export==='mp3')await exportMp3(b);else await exportPDF(b.dataset.export,b);}catch(e){toast('导出失败：'+e.message);b.disabled=false;}});
}
function pdfPageLabel(text,width=1000,height=60){return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}"><rect width="100%" height="100%" fill="white"/><text x="${width/2}" y="${height*.68}" text-anchor="middle" font-size="13" font-family="Xingkai SC, STXingkai, 华文行楷, Kaiti SC, STKaiti, KaiTi, cursive" fill="#999999">${esc(text)}</text></svg>`;}
async function exportPDF(kind,button){
 if(!window.jspdf)throw new Error('PDF 组件未加载');const old=button.innerHTML;button.disabled=true;button.textContent='正在排版…';
 try{
 const p=project(),pdf=new jspdf.jsPDF({unit:'mm',format:'a4',compress:true});
 const top=await svgImage(pdfPageLabel('歌的起点'),1000,60),bottom=await svgImage(pdfPageLabel('每个人都会作曲'),1000,60);
 const frame=()=>{pdf.setFillColor(255,255,255);pdf.rect(0,0,210,297,'F');pdf.addImage(top,'PNG',15,6,180,10.8);pdf.setTextColor(60,60,60);pdf.setFontSize(9);pdf.text(String(pdf.getNumberOfPages()),15,12);pdf.addImage(bottom,'PNG',15,282,180,10.8);};frame();
 const title=`<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="160"><rect width="100%" height="100%" fill="white"/><text x="500" y="54" text-anchor="middle" font-size="42" font-family="Kaiti SC, STKaiti, KaiTi, 楷体, serif">${esc(p.title)}</text><text x="970" y="108" text-anchor="end" font-size="20">作词：${esc(p.lyricist||'未署名')}</text><text x="970" y="142" text-anchor="end" font-size="20">作曲：${esc(p.composer||'未署名')}</text></svg>`;
 pdf.addImage(await svgImage(title,1000,160),'PNG',15,20,180,28.8);let y=53;
 for(const row of systemModel(p)){let svg=engravingSVG(row,kind,false).replaceAll('#fffefa','#ffffff'),h=kind==='staff'?277:155;if(kind==='staff'){svg=svg.replace(`0 0 ${row.width} 277`,`0 ${row.first?65:90} ${row.width} ${row.first?212:187}`);h=row.first?212:187;}const height=180*h/row.width;
 if(y+height>276){pdf.addPage();frame();y=24;}pdf.addImage(await svgImage(svg,row.width,h),'PNG',15,y,180,height);y+=height+12;
 }
 pdf.save(p.title+'-'+(kind==='staff'?'五线谱':'简谱')+'.pdf');toast('PDF 乐谱已下载');
 }finally{button.disabled=false;button.innerHTML=old;}
}
function parseLyrics(text){
  return text.split(/\r?\n/).map(line=>({text:(/[A-Za-z]/.test(line)?line.trim().replace(/[，。！？；,.!?;]/g,''):line.replace(/[\s，。！？；,.!?;]/g,'')),punct:line.trim().match(/[，。！？；,.!?;]$/)?.[0]||''})).filter(l=>l.text);
}

function goBackStep(){const p=project();if(p.step<=0)return;stop();mutate(()=>p.step--);selected=null;render();}

function renderMeter(){
  const p=project();$('#stage').innerHTML=heading('选择节拍','这次帮你选好4/4拍啦','')+`<button id="meter44" class="${p.meter?'primary':''}">4/4 拍 ${p.meter?'✓':''}</button>`;
  $('#meter44').onclick=()=>{mutate(()=>p.meter='4/4');render();};
  nav(true,'选择速度',()=>{if(!p.meter)return;mutate(()=>p.step=2);render();});$('#next').disabled=!p.meter;
}
function archiveStudio(){
  if(!db.studio)return;db.songs??=[];
  const copy=clone(db.studio);copy.songId??=Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8);copy.savedAt=new Date().toISOString();
  const i=db.songs.findIndex(s=>s.songId===copy.songId);if(i<0)db.songs.unshift(copy);else db.songs[i]=copy;
  db.studio.songId=copy.songId;
}
// Write the complete next library before replacing in-memory data.
function saveLibraryChange(next){
  try{persistDB(next);}catch(e){toast('未能保存这次操作，作品保持不变');return false;}
  db=next;saveOK=true;return true;
}
function deleteStudioSong(songId){
  const saved=(db.songs||[]).find(p=>p.songId===songId);if(!saved||saved.level!==0)return false;
  const current=db.studio?.songId===songId,wasActive=current&&db.active==='studio',p=current?db.studio:saved;
  const next={...db,songs:db.songs.filter(s=>s.songId!==songId),deletedSongs:[{project:clone(p),deletedAt:new Date().toISOString()},...(db.deletedSongs||[]).filter(s=>s.project.songId!==songId)]};
  if(current){next.studio=null;if(db.active==='studio')next.active='one';}
  if(!saveLibraryChange(next))return false;
  if(wasActive){selected=null;undo=[];redo=[];}
  return true;
}
function restoreStudioSong(songId){
  const entry=(db.deletedSongs||[]).find(s=>s.project.songId===songId);if(!entry)return false;
  const p=clone(entry.project);
  if((db.songs||[]).some(s=>s.songId===p.songId)||db.studio?.songId===p.songId)p.songId=Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8);
  return saveLibraryChange({...db,songs:[p,...(db.songs||[])],deletedSongs:db.deletedSongs.filter(s=>s.project.songId!==songId)});
}
function confirmDeleteStudioSong(songId){
  const p=(db.songs||[]).find(s=>s.songId===songId);if(!p)return;
  const m=$('#modal');m.innerHTML=`<h2>删除《${esc(p.title)}》？</h2><p>删除后可在“已删除作品”中恢复。</p><div class="actions"><button id="cancelDeleteSong" autofocus>取消</button><button id="confirmDeleteSong" class="delete-confirm">删除作品</button></div>`;
  $('#cancelDeleteSong').onclick=()=>m.close();
  $('#confirmDeleteSong').onclick=()=>{if(!deleteStudioSong(songId))return;m.close();studioHome();toast('已删除，可在“已删除作品”中恢复');};m.showModal();
}
function studioHome(){
  setHomePage(false);
  stop();archiveStudio();db.view='library';save();
  $('#journey').classList.remove('active');$('#studio').classList.add('active');
  $('#app').innerHTML=`<div class="toolbar"><button id="libraryBack">← 首页</button><button id="newSong" class="primary">新的歌曲</button></div><h2>旧的印迹</h2>${(db.songs||[]).length?db.songs.map((p,i)=>`<article class="song-entry"><div class="song-entry-info"><h3>${esc(p.title)}</h3><p>${esc(p.lines.map(l=>l.text).join('，').slice(0,80))}</p></div><div class="song-entry-actions"><button data-song="${i}">继续创作 →</button><button class="delete-song" data-delete-song="${esc(p.songId)}" aria-label="删除作品：${esc(p.title)}">删除</button></div></article>`).join(''):'<p>还没有保存的歌曲。写一首试试？</p>'}${(db.deletedSongs||[]).length?`<details class="deleted-songs"><summary>已删除作品（${db.deletedSongs.length}）</summary>${db.deletedSongs.map(({project:p})=>`<article class="song-entry"><div class="song-entry-info"><h3>${esc(p.title)}</h3></div><button data-restore-song="${esc(p.songId)}" aria-label="恢复作品：${esc(p.title)}">恢复</button></article>`).join('')}</details>`:''}`;
  $('#newSong').onclick=newSong;$('#libraryBack').onclick=home;$$('[data-song]').forEach(b=>b.onclick=()=>{db.studio=clone(db.songs[+b.dataset.song]);start('studio');});
  $$('[data-delete-song]').forEach(b=>b.onclick=()=>confirmDeleteStudioSong(b.dataset.deleteSong));
  $$('[data-restore-song]').forEach(b=>b.onclick=()=>{if(!restoreStudioSong(b.dataset.restoreSong))return;studioHome();toast('作品已恢复');});
}

function stepNames(p=project()){return p.level===4?['划分词组','选择节拍','选择速度','安排节奏','选择调式','写出旋律','加入跳音','完成作品','保存作品']:p.level===0?['划分词组','选择节拍','选择速度','选择调式','开始创作','完成作品','保存作品']:p.level===2?['旋律的重复','中间的休息','节奏更改','完成作品','保存作品']:['划分词组','选择节拍','选择速度','安排节奏','选择调式','写出旋律','完成作品','保存作品'];}
function renderMode(){const p=project();$('#stage').innerHTML=heading('选择调式','这次我们就选C大调啦','')+`<button id="modeC" class="${p.mode?'primary':''}">C大调 ${p.mode?'✓':''}</button>`;$('#modeC').onclick=()=>{mutate(()=>p.mode='C大调');render();};nav(true,'写出旋律',()=>{if(!p.mode)return;mutate(()=>p.step=5);render();});$('#next').disabled=!p.mode;}

function renderCredits(){
  const p=project();$('#stage').innerHTML=heading('完成作品','加入作品名称和作曲作词家姓名。','')+`<div class="score-controls"><div class="score-playback-tools"><button type="button" id="finishPlay" class="primary">▶ 整首播放</button></div></div><div id="scoreArea" data-readonly="true" data-complete="true">${completedScoreHTML(true)}</div><div class="actions"><button id="creditBack">← 上一步：${sentenceLesson(p)?stepNames(p)[creditStep(p)-1]:p.level===2?'节奏更改':p.level===0?'开始创作':p.level===4?'加入跳音':'写出旋律'}</button><button id="creditNext" class="primary">下一步：保存作品 →</button></div>`;
  $('#finishPlay').onclick=togglePlay;updatePlay();
  for(const [id,key] of [['workTitle','title'],['lyricistName','lyricist'],['composerName','composer']])$('#'+id).oninput=e=>{p[key]=e.target.value;save();};
  $('#creditBack').onclick=()=>{mutate(()=>p.step=sentenceLesson(p)?creditStep(p)-1:p.level===2?2:p.level===0?4:p.level===4?6:5);stop();render();};
  $('#creditNext').onclick=()=>{mutate(()=>{p.title=$('#workTitle').value.trim()||'未命名作品';p.lyricist=$('#lyricistName').value.trim();p.composer=$('#composerName').value.trim();p.creditsConfirmed=true;p.step=saveStep(p);p.maxStep=p.step;p.saveFlow=1;});render();};
}

function creditStep(p=project()){return p.level===2?3:p.level===4?7:p.level===0?5:6;}
function saveStep(p=project()){return creditStep(p)+1;}

function restartJourney(){
  stop();const snapshot={};for(const key of CHAPTER_KEYS.slice(1))if(db[key])snapshot[key]=clone(db[key]);
  // Persist the recovery copy before replacing any lesson data.
  const next={...db,...Object.fromEntries(CHAPTER_KEYS.slice(1).map(k=>[k,null])),journeyBackup:snapshot,one:fresh(),active:'one',view:'editor'};
  try{persistDB(next);}catch(e){toast('无法保存旧进度，暂未重置');return;}
  db=next;start('one');toast('已从第一关重新开始，旧进度可在首页恢复');
}
function restoreJourney(){
  if(!db.journeyBackup)return false;stop();const previous=db,next=clone(db),old=next.journeyBackup,current={};
  for(const key of CHAPTER_KEYS.slice(1)){if(next[key])current[key]=next[key];next[key]=old[key]??null;}
  next.journeyBackup=current;next.view='home';
  // Migrate an isolated candidate; a failed write must leave both journeys intact.
  try{db=next;migrateV2();db.view='home';if(!db[db.active])db.active='one';persistDB(db);}catch(e){db=previous;toast('无法保存恢复结果，当前进度与备份保持不变');return false;}
  selected=null;groupIndex=0;undo=[];redo=[];saveOK=true;render();return true;
}
